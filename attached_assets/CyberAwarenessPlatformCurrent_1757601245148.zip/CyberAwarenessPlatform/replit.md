# Overview

A multi-tenant cybersecurity awareness training platform that provides white-labeled phishing simulation, AI-powered learning, and comprehensive user management capabilities. The platform serves three user roles: Super Admins who manage the entire system, Client Admins who manage their organization's users and campaigns, and End Users who complete training courses and receive phishing simulations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client is built with React and TypeScript using Vite as the build tool. The UI leverages Radix UI components with Tailwind CSS for styling, following the shadcn/ui design system with a "new-york" style configuration. The application uses Wouter for client-side routing and TanStack Query for server state management and caching.

## Backend Architecture
The server runs on Express.js with TypeScript, structured as a monorepo with shared schemas between client and server. API routes are centralized in the `/server/routes.ts` file with middleware for authentication, role-based access control, and client isolation. The authentication system uses JWT tokens with bcrypt for password hashing.

## Database Design
The application uses a multi-database approach with MongoDB as the primary database via the native MongoDB driver (not Mongoose). Drizzle ORM is configured for PostgreSQL support but currently uses MongoDB collections. The schema defines entities for Users, Clients, Courses, Phishing Campaigns, Analytics Events, and Sessions with proper multi-tenant isolation through client IDs.

## Authentication & Authorization
JWT-based authentication with role-based access control supporting three roles: super_admin, client_admin, and user. The middleware enforces client-specific data isolation, ensuring users can only access data within their organization. Tokens include user ID, email, role, and client ID for proper authorization.

## AI Integration
OpenAI GPT-5 integration provides AI-powered features including course customization, quiz generation, training recommendations, and an AI assistant chat interface. The AI service adapts responses based on user roles and provides contextual cybersecurity guidance.

## Email Services
SendGrid integration handles phishing campaign email delivery with comprehensive tracking capabilities including email opens, clicks, and user interactions. The service supports bulk email sending with campaign tracking and analytics.

## Multi-Tenant Architecture
Client isolation is enforced at the database level through client IDs, with each organization having separate branding, settings, user management, and campaign data. The platform supports white-labeling with customizable logos, colors, and CSS themes per client.

# External Dependencies

## Database Services
- **MongoDB**: Primary database using native MongoDB driver for user management, campaigns, courses, and analytics
- **PostgreSQL**: Configured via Drizzle ORM for potential future migration or additional data storage
- **Neon Database**: Serverless PostgreSQL provider integration available

## AI & ML Services  
- **OpenAI API**: GPT-5 model integration for AI assistant, course recommendations, quiz generation, and content customization

## Communication Services
- **SendGrid**: Email delivery service for phishing campaigns with tracking capabilities including open rates, click tracking, and delivery analytics

## UI & Design Systems
- **Radix UI**: Comprehensive component library providing accessible primitives for dialogs, forms, navigation, and data display
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens and responsive design capabilities
- **Lucide React**: Icon library providing consistent iconography throughout the application

## Development & Build Tools
- **Vite**: Fast build tool and development server with React plugin support
- **TypeScript**: Type safety across the entire application stack
- **TanStack Query**: Server state management with caching, background updates, and optimistic updates
- **Chart.js**: Data visualization library for analytics dashboards and reporting features