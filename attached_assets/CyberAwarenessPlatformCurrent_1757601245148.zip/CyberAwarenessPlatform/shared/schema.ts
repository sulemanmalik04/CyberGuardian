import { pgTable, varchar, text, timestamp, boolean, integer, json, serial, pgEnum } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import { createInsertSchema, createSelectSchema } from 'drizzle-zod';
import { z } from 'zod';

// Enums
export const userRoleEnum = pgEnum('user_role', ['super_admin', 'client_admin', 'user']);
export const userStatusEnum = pgEnum('user_status', ['active', 'inactive', 'suspended']);
export const difficultyEnum = pgEnum('difficulty', ['beginner', 'intermediate', 'advanced']);
export const campaignStatusEnum = pgEnum('campaign_status', ['draft', 'scheduled', 'sending', 'completed', 'cancelled']);
export const licensingStatusEnum = pgEnum('licensing_status', ['active', 'expired', 'suspended']);

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  password: varchar('password', { length: 255 }).notNull(),
  firstName: varchar('first_name', { length: 255 }).notNull(),
  lastName: varchar('last_name', { length: 255 }).notNull(),
  role: userRoleEnum('role').notNull(),
  clientId: integer('client_id'),
  department: varchar('department', { length: 255 }),
  language: varchar('language', { length: 10 }).default('en').notNull(),
  status: userStatusEnum('status').default('active').notNull(),
  progress: json('progress').$type<{
    coursesCompleted?: number;
    totalCourses?: number;
    lastActivity?: string;
  }>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Clients table
export const clients = pgTable('clients', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  branding: json('branding').$type<{
    logo?: string;
    primaryColor?: string;
    secondaryColor?: string;
    customCss?: string;
  }>(),
  expirationDate: timestamp('expiration_date').notNull(),
  licensingStatus: licensingStatusEnum('licensing_status').default('active').notNull(),
  settings: json('settings').$type<{
    maxUsers?: number;
    features?: string[];
    domains?: string[];
  }>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Courses table
export const courses = pgTable('courses', {
  id: serial('id').primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),
  content: json('content').$type<Array<{
    type: 'video' | 'text' | 'quiz' | 'interactive';
    title: string;
    content: string;
    duration?: number;
    questions?: Array<{
      question: string;
      options: string[];
      correctAnswer: number;
      explanation?: string;
    }>;
  }>>().notNull(),
  language: varchar('language', { length: 10 }).default('en').notNull(),
  difficulty: difficultyEnum('difficulty').default('beginner').notNull(),
  estimatedDuration: integer('estimated_duration').notNull(), // in minutes
  tags: json('tags').$type<string[]>(),
  isPublished: boolean('is_published').default(false).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Phishing campaigns table
export const phishingCampaigns = pgTable('phishing_campaigns', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  clientId: integer('client_id').notNull(),
  status: campaignStatusEnum('status').default('draft').notNull(),
  template: json('template').$type<{
    subject: string;
    content: string;
    attachments?: Array<{
      filename: string;
      content: string;
      type: string;
    }>;
  }>().notNull(),
  targetUsers: json('target_users').$type<string[]>().notNull(),
  schedule: json('schedule').$type<{
    sendDate?: string;
    timeZone?: string;
    sendImmediately?: boolean;
  }>(),
  tracking: json('tracking').$type<{
    sent: number;
    opened: number;
    clicked: number;
    reported: number;
  }>(),
  domains: json('domains').$type<string[]>(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Analytics events table
export const analyticsEvents = pgTable('analytics_events', {
  id: serial('id').primaryKey(),
  eventType: varchar('event_type', { length: 100 }).notNull(),
  userId: varchar('user_id', { length: 255 }),
  campaignId: varchar('campaign_id', { length: 255 }),
  clientId: varchar('client_id', { length: 255 }).notNull(),
  metadata: json('metadata'),
  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
});

// Sessions table
export const sessions = pgTable('sessions', {
  id: varchar('id', { length: 255 }).primaryKey(),
  userId: integer('user_id').notNull(),
  token: text('token').notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  client: one(clients, {
    fields: [users.clientId],
    references: [clients.id],
  }),
  sessions: many(sessions),
}));

export const clientsRelations = relations(clients, ({ many }) => ({
  users: many(users),
  campaigns: many(phishingCampaigns),
}));

export const campaignsRelations = relations(phishingCampaigns, ({ one }) => ({
  client: one(clients, {
    fields: [phishingCampaigns.clientId],
    references: [clients.id],
  }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export const selectUserSchema = createSelectSchema(users);
export type User = z.infer<typeof selectUserSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

export const insertClientSchema = createInsertSchema(clients).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export const selectClientSchema = createSelectSchema(clients);
export type Client = z.infer<typeof selectClientSchema>;
export type InsertClient = z.infer<typeof insertClientSchema>;

export const insertCourseSchema = createInsertSchema(courses).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export const selectCourseSchema = createSelectSchema(courses);
export type Course = z.infer<typeof selectCourseSchema>;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export const insertPhishingCampaignSchema = createInsertSchema(phishingCampaigns).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export const selectPhishingCampaignSchema = createSelectSchema(phishingCampaigns);
export type PhishingCampaign = z.infer<typeof selectPhishingCampaignSchema>;
export type InsertPhishingCampaign = z.infer<typeof insertPhishingCampaignSchema>;

export const insertAnalyticsEventSchema = createInsertSchema(analyticsEvents).omit({ 
  id: true, 
  timestamp: true 
});
export const selectAnalyticsEventSchema = createSelectSchema(analyticsEvents);
export type AnalyticsEvent = z.infer<typeof selectAnalyticsEventSchema>;
export type InsertAnalyticsEvent = z.infer<typeof insertAnalyticsEventSchema>;

export const insertSessionSchema = createInsertSchema(sessions).omit({ 
  createdAt: true, 
  updatedAt: true 
});
export const selectSessionSchema = createSelectSchema(sessions);
export type Session = z.infer<typeof selectSessionSchema>;
export type InsertSession = z.infer<typeof insertSessionSchema>;

// Login and register schemas
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});
export type LoginRequest = z.infer<typeof loginSchema>;

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  clientId: z.number().optional(),
});
export type RegisterRequest = z.infer<typeof registerSchema>;

// Dashboard stats interface
export interface DashboardStats {
  activeUsers: number;
  campaignsSent: number;
  completionRate: number;
  securityScore: number;
  totalCourses: number;
  recentActivity: number;
}