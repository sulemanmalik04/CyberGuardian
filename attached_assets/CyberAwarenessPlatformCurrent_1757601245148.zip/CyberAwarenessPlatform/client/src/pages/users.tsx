import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/AppShell";
import { TopHeader } from "@/components/layout/TopHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { UserImportModal } from "@/components/modals/UserImportModal";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Users, UserCheck, UserX, Upload, Filter, Edit, Trash2 } from "lucide-react";

export default function UsersPage() {
  const [importModalOpen, setImportModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: users, isLoading } = useQuery({
    queryKey: ['/api/users', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getUsers(user?.clientId);
      return response.data || [];
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiClient.deleteUser(userId);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
    },
  });

  const updateUserStatusMutation = useMutation({
    mutationFn: async ({ userId, status }: { userId: string; status: string }) => {
      const response = await apiClient.updateUser(userId, { status });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User status updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update user status",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'inactive': return 'secondary';
      case 'suspended': return 'destructive';
      default: return 'outline';
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'super_admin': return 'destructive';
      case 'client_admin': return 'default';
      case 'user': return 'secondary';
      default: return 'outline';
    }
  };

  const getRoleText = (role: string) => {
    switch (role) {
      case 'super_admin': return 'Super Admin';
      case 'client_admin': return 'Client Admin';
      case 'user': return 'User';
      default: return 'Unknown';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getTrainingProgress = (userProgress: any) => {
    if (!userProgress?.totalCourses || userProgress.totalCourses === 0) return 0;
    return Math.round((userProgress.coursesCompleted / userProgress.totalCourses) * 100);
  };

  const filteredUsers = users?.filter((user: any) => {
    const matchesSearch = 
      user.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.department?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || user.status === statusFilter;
    const matchesRole = roleFilter === "all" || user.role === roleFilter;

    return matchesSearch && matchesStatus && matchesRole;
  }) || [];

  const handleDeleteUser = async (userId: string) => {
    if (confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
      deleteUserMutation.mutate(userId);
    }
  };

  const handleToggleUserStatus = (userId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    updateUserStatusMutation.mutate({ userId, status: newStatus });
  };

  const uniqueDepartments = [...new Set(users?.map((u: any) => u.department).filter(Boolean))] || [];
  const userStats = {
    total: users?.length || 0,
    active: users?.filter((u: any) => u.status === 'active').length || 0,
    inactive: users?.filter((u: any) => u.status === 'inactive').length || 0,
    suspended: users?.filter((u: any) => u.status === 'suspended').length || 0,
  };

  return (
    <AppShell>
      <TopHeader 
        title="User Management"
        subtitle="Manage user accounts, roles, and training assignments"
      />
      
      <div className="p-6 space-y-6" data-testid="users-page">
        
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-users"
              />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32" data-testid="status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>

            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-32" data-testid="role-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="user">Users</SelectItem>
                <SelectItem value="client_admin">Admins</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={() => setImportModalOpen(true)}
            data-testid="import-users-button"
          >
            <Upload className="w-4 h-4 mr-2" />
            Import Users
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Users</p>
                  <p className="text-2xl font-bold" data-testid="total-users">
                    {userStats.total}
                  </p>
                </div>
                <Users className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Users</p>
                  <p className="text-2xl font-bold" data-testid="active-users">
                    {userStats.active}
                  </p>
                </div>
                <UserCheck className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Inactive Users</p>
                  <p className="text-2xl font-bold" data-testid="inactive-users">
                    {userStats.inactive}
                  </p>
                </div>
                <UserX className="h-8 w-8 text-secondary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Departments</p>
                  <p className="text-2xl font-bold" data-testid="total-departments">
                    {uniqueDepartments.length}
                  </p>
                </div>
                <Filter className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Users Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Users ({filteredUsers.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="text-center py-8">
                <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {users?.length === 0 ? "No users yet" : "No users found"}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {users?.length === 0 
                    ? "Get started by importing users from CSV or Azure AD"
                    : "Try adjusting your search criteria or filters"
                  }
                </p>
                {users?.length === 0 && (
                  <Button onClick={() => setImportModalOpen(true)} data-testid="import-first-users">
                    <Upload className="w-4 h-4 mr-2" />
                    Import Your First Users
                  </Button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Training Progress</TableHead>
                      <TableHead>Language</TableHead>
                      <TableHead>Joined</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user: any, index: number) => (
                      <TableRow key={user._id} data-testid={`user-row-${index}`}>
                        <TableCell>
                          <div>
                            <p className="font-medium text-foreground" data-testid={`user-name-${index}`}>
                              {user.firstName} {user.lastName}
                            </p>
                            <p className="text-sm text-muted-foreground" data-testid={`user-email-${index}`}>
                              {user.email}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getRoleColor(user.role)} data-testid={`user-role-${index}`}>
                            {getRoleText(user.role)}
                          </Badge>
                        </TableCell>
                        <TableCell data-testid={`user-department-${index}`}>
                          {user.department || '-'}
                        </TableCell>
                        <TableCell>
                          <Badge variant={getStatusColor(user.status)} data-testid={`user-status-${index}`}>
                            {user.status}
                          </Badge>
                        </TableCell>
                        <TableCell data-testid={`user-progress-${index}`}>
                          <div className="flex items-center space-x-2">
                            <div className="w-full bg-muted rounded-full h-2 max-w-20">
                              <div 
                                className="bg-primary h-2 rounded-full transition-all"
                                style={{ width: `${getTrainingProgress(user.progress)}%` }}
                              />
                            </div>
                            <span className="text-sm text-muted-foreground whitespace-nowrap">
                              {getTrainingProgress(user.progress)}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell data-testid={`user-language-${index}`}>
                          {user.language?.toUpperCase() || 'EN'}
                        </TableCell>
                        <TableCell data-testid={`user-joined-${index}`}>
                          {formatDate(user.createdAt)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleToggleUserStatus(user._id, user.status)}
                              disabled={updateUserStatusMutation.isPending}
                              data-testid={`toggle-status-${index}`}
                            >
                              {user.status === 'active' ? (
                                <UserX className="h-4 w-4" />
                              ) : (
                                <UserCheck className="h-4 w-4" />
                              )}
                            </Button>
                            
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteUser(user._id)}
                              disabled={deleteUserMutation.isPending}
                              data-testid={`delete-user-${index}`}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <UserImportModal 
          isOpen={importModalOpen}
          onClose={() => setImportModalOpen(false)}
        />

      </div>
    </AppShell>
  );
}
