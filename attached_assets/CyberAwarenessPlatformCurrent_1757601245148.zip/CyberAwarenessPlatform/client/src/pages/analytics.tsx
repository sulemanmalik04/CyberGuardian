import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { AppShell } from '@/components/layout/AppShell';
import { TopHeader } from '@/components/layout/TopHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { AnalyticsChart } from '@/components/charts/AnalyticsChart';
import { apiClient } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Download, 
  Filter,
  Calendar,
  Users,
  Mail,
  MousePointer,
  Eye,
  AlertTriangle
} from 'lucide-react';

export default function Analytics() {
  const [dateRange, setDateRange] = useState('30d');
  const [campaignFilter, setCampaignFilter] = useState('all');
  const { user } = useAuth();

  const { data: analyticsData, isLoading } = useQuery({
    queryKey: ['/api/analytics', user?.clientId, dateRange, campaignFilter],
    queryFn: async () => {
      const endDate = new Date();
      const startDate = new Date();
      
      switch (dateRange) {
        case '7d':
          startDate.setDate(endDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(endDate.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(endDate.getDate() - 90);
          break;
        case '1y':
          startDate.setFullYear(endDate.getFullYear() - 1);
          break;
      }

      const filters: any = {
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
      };

      if (user?.clientId) filters.clientId = user.clientId;
      if (campaignFilter !== 'all') filters.campaignId = campaignFilter;

      const response = await apiClient.getAnalytics(filters);
      return response.data || [];
    },
  });

  const { data: campaigns } = useQuery({
    queryKey: ['/api/campaigns', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getCampaigns(user?.clientId);
      return response.data || [];
    },
  });

  const { data: dashboardStats } = useQuery({
    queryKey: ['/api/dashboard/stats', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getDashboardStats(user?.clientId);
      return response.data;
    },
  });

  const processAnalyticsData = () => {
    if (!analyticsData) return null;

    // Group events by type
    const eventsByType = analyticsData.reduce((acc: any, event: any) => {
      acc[event.eventType] = (acc[event.eventType] || 0) + 1;
      return acc;
    }, {});

    // Group events by date
    const eventsByDate = analyticsData.reduce((acc: any, event: any) => {
      const date = new Date(event.timestamp).toLocaleDateString();
      if (!acc[date]) acc[date] = {};
      acc[date][event.eventType] = (acc[date][event.eventType] || 0) + 1;
      return acc;
    }, {});

    // Convert to chart data
    const dateLabels = Object.keys(eventsByDate).sort();
    const timeSeriesData = dateLabels.map(date => ({
      date,
      sent: eventsByDate[date]['email_sent'] || 0,
      opened: eventsByDate[date]['email_opened'] || 0,
      clicked: eventsByDate[date]['link_clicked'] || 0,
      reported: eventsByDate[date]['phishing_reported'] || 0,
    }));

    const eventTypeData = Object.entries(eventsByType).map(([type, count]) => ({
      type: type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()),
      count,
    }));

    return {
      eventsByType,
      timeSeriesData,
      eventTypeData,
      totalEvents: analyticsData.length,
    };
  };

  const getMetrics = () => {
    const processed = processAnalyticsData();
    if (!processed) return null;

    const { eventsByType } = processed;
    const sent = eventsByType['email_sent'] || 0;
    const opened = eventsByType['email_opened'] || 0;
    const clicked = eventsByType['link_clicked'] || 0;
    const reported = eventsByType['phishing_reported'] || 0;

    return {
      openRate: sent > 0 ? ((opened / sent) * 100).toFixed(1) : '0',
      clickRate: sent > 0 ? ((clicked / sent) * 100).toFixed(1) : '0',
      reportRate: sent > 0 ? ((reported / sent) * 100).toFixed(1) : '0',
      susceptibilityRate: sent > 0 ? (((clicked - reported) / sent) * 100).toFixed(1) : '0',
    };
  };

  const handleExport = () => {
    if (!analyticsData) return;

    const csvData = analyticsData.map((event: any) => ({
      Date: new Date(event.timestamp).toLocaleDateString(),
      Time: new Date(event.timestamp).toLocaleTimeString(),
      Event: event.eventType,
      Campaign: event.campaignId || 'N/A',
      User: event.userId || 'N/A',
      Metadata: JSON.stringify(event.metadata || {}),
    }));

    const csv = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-${dateRange}-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const processed = processAnalyticsData();
  const metrics = getMetrics();

  return (
    <AppShell>
      <TopHeader 
        title="Analytics & Reports"
        subtitle="Track campaign performance and security awareness metrics"
      />
      
      <div className="p-6 space-y-6" data-testid="analytics-page">
        
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center space-x-4">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-32" data-testid="date-range-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>

            <Select value={campaignFilter} onValueChange={setCampaignFilter}>
              <SelectTrigger className="w-48" data-testid="campaign-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Campaigns</SelectItem>
                {campaigns?.map((campaign: any) => (
                  <SelectItem key={campaign._id} value={campaign._id}>
                    {campaign.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={handleExport}
            disabled={!analyticsData || analyticsData.length === 0}
            data-testid="export-analytics"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
        </div>

        {/* Key Metrics */}
        {metrics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Email Open Rate</p>
                    <p className="text-2xl font-bold" data-testid="open-rate">
                      {metrics.openRate}%
                    </p>
                    <div className="flex items-center text-sm text-accent">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Good engagement
                    </div>
                  </div>
                  <Eye className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Click Rate</p>
                    <p className="text-2xl font-bold" data-testid="click-rate">
                      {metrics.clickRate}%
                    </p>
                    <div className="flex items-center text-sm text-destructive">
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      Needs attention
                    </div>
                  </div>
                  <MousePointer className="h-8 w-8 text-accent" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Report Rate</p>
                    <p className="text-2xl font-bold" data-testid="report-rate">
                      {metrics.reportRate}%
                    </p>
                    <div className="flex items-center text-sm text-accent">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Security aware
                    </div>
                  </div>
                  <Mail className="h-8 w-8 text-secondary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Susceptibility Rate</p>
                    <p className="text-2xl font-bold" data-testid="susceptibility-rate">
                      {metrics.susceptibilityRate}%
                    </p>
                    <div className="flex items-center text-sm text-destructive">
                      <TrendingDown className="w-3 h-3 mr-1" />
                      Risk indicator
                    </div>
                  </div>
                  <Users className="h-8 w-8 text-destructive" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : !processed || processed.totalEvents === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No Analytics Data</h3>
              <p className="text-muted-foreground mb-4">
                No events found for the selected time period and filters.
              </p>
              <p className="text-sm text-muted-foreground">
                Try adjusting your date range or launch some campaigns to generate data.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            
            {/* Time Series Chart */}
            <AnalyticsChart
              type="line"
              title="Campaign Activity Over Time"
              data={processed.timeSeriesData.map(item => ({
                date: item.date,
                events: item.sent + item.opened + item.clicked + item.reported,
              }))}
              xKey="date"
              yKey="events"
              height={300}
              className="lg:col-span-2"
            />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Event Distribution */}
              <AnalyticsChart
                type="pie"
                title="Event Type Distribution"
                data={processed.eventTypeData}
                xKey="type"
                yKey="count"
                height={300}
              />

              {/* Campaign Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>Campaign Performance Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {campaigns?.slice(0, 5).map((campaign: any, index: number) => {
                      const campaignEvents = analyticsData?.filter((e: any) => e.campaignId === campaign._id) || [];
                      const sent = campaignEvents.filter((e: any) => e.eventType === 'email_sent').length;
                      const clicked = campaignEvents.filter((e: any) => e.eventType === 'link_clicked').length;
                      const clickRate = sent > 0 ? ((clicked / sent) * 100).toFixed(1) : '0';
                      
                      return (
                        <div key={campaign._id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg" data-testid={`campaign-summary-${index}`}>
                          <div>
                            <p className="font-medium text-foreground">{campaign.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {sent} sent • {clicked} clicked
                            </p>
                          </div>
                          <Badge variant={parseFloat(clickRate) > 20 ? 'destructive' : 'secondary'}>
                            {clickRate}% click rate
                          </Badge>
                        </div>
                      );
                    })}
                    
                    {!campaigns || campaigns.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        No campaigns to display
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

            </div>

            {/* Detailed Event Timeline */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {analyticsData?.slice(0, 20).map((event: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg" data-testid={`event-${index}`}>
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${
                          event.eventType === 'email_sent' ? 'bg-primary' :
                          event.eventType === 'email_opened' ? 'bg-accent' :
                          event.eventType === 'link_clicked' ? 'bg-destructive' :
                          event.eventType === 'phishing_reported' ? 'bg-secondary' :
                          'bg-muted'
                        }`} />
                        <div>
                          <p className="text-sm font-medium">
                            {event.eventType.replace('_', ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {event.metadata?.email || event.userId || 'System event'}
                          </p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {new Date(event.timestamp).toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

          </div>
        )}

      </div>
    </AppShell>
  );
}
