import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/AppShell";
import { TopHeader } from "@/components/layout/TopHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CampaignModal } from "@/components/modals/CampaignModal";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Plus, Search, Mail, Users, BarChart, Calendar, Eye, Play, Pause, Trash2 } from "lucide-react";

export default function Campaigns() {
  const [campaignModalOpen, setCampaignModalOpen] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const { user } = useAuth();

  const { data: campaigns, isLoading } = useQuery({
    queryKey: ['/api/campaigns', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getCampaigns(user?.clientId);
      return response.data || [];
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'default';
      case 'sending': return 'destructive';
      case 'scheduled': return 'secondary';
      case 'draft': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'sending': return 'Sending';
      case 'scheduled': return 'Scheduled';
      case 'draft': return 'Draft';
      default: return 'Unknown';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getClickRate = (campaign: any) => {
    if (!campaign.tracking?.sent || campaign.tracking.sent === 0) return '0%';
    return `${Math.round((campaign.tracking.clicked / campaign.tracking.sent) * 100)}%`;
  };

  const getOpenRate = (campaign: any) => {
    if (!campaign.tracking?.sent || campaign.tracking.sent === 0) return '0%';
    return `${Math.round((campaign.tracking.opened / campaign.tracking.sent) * 100)}%`;
  };

  const filteredCampaigns = campaigns?.filter((campaign: any) =>
    campaign.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const handleEditCampaign = (campaign: any) => {
    setSelectedCampaign(campaign);
    setCampaignModalOpen(true);
  };

  const handleNewCampaign = () => {
    setSelectedCampaign(null);
    setCampaignModalOpen(true);
  };

  const handleModalClose = () => {
    setCampaignModalOpen(false);
    setSelectedCampaign(null);
  };

  return (
    <AppShell>
      <TopHeader 
        title="Phishing Campaigns"
        subtitle="Create and manage phishing simulation campaigns"
      />
      
      <div className="p-6 space-y-6" data-testid="campaigns-page">
        
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search campaigns..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-campaigns"
              />
            </div>
          </div>
          
          <Button 
            onClick={handleNewCampaign}
            data-testid="new-campaign-button"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Campaign
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Campaigns</p>
                  <p className="text-2xl font-bold" data-testid="total-campaigns">
                    {campaigns?.length || 0}
                  </p>
                </div>
                <Mail className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Active Campaigns</p>
                  <p className="text-2xl font-bold" data-testid="active-campaigns">
                    {campaigns?.filter((c: any) => c.status === 'sending' || c.status === 'scheduled').length || 0}
                  </p>
                </div>
                <Play className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Users Targeted</p>
                  <p className="text-2xl font-bold" data-testid="total-targeted">
                    {campaigns?.reduce((sum: number, c: any) => sum + (c.targets?.totalCount || 0), 0) || 0}
                  </p>
                </div>
                <Users className="h-8 w-8 text-secondary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Click Rate</p>
                  <p className="text-2xl font-bold" data-testid="avg-click-rate">
                    {campaigns?.length > 0 
                      ? Math.round(campaigns.reduce((sum: number, c: any) => {
                          const rate = c.tracking?.sent > 0 ? (c.tracking.clicked / c.tracking.sent) * 100 : 0;
                          return sum + rate;
                        }, 0) / campaigns.length) + '%'
                      : '0%'
                    }
                  </p>
                </div>
                <BarChart className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Campaigns Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Campaigns</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredCampaigns.length === 0 ? (
              <div className="text-center py-8">
                <Mail className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {campaigns?.length === 0 ? "No campaigns yet" : "No campaigns found"}
                </h3>
                <p className="text-muted-foreground mb-4">
                  {campaigns?.length === 0 
                    ? "Get started by creating your first phishing simulation campaign"
                    : "Try adjusting your search criteria"
                  }
                </p>
                {campaigns?.length === 0 && (
                  <Button onClick={handleNewCampaign} data-testid="create-first-campaign">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Campaign
                  </Button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Campaign Name</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Targets</TableHead>
                      <TableHead>Sent</TableHead>
                      <TableHead>Opened</TableHead>
                      <TableHead>Clicked</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCampaigns.map((campaign: any, index: number) => (
                      <TableRow key={campaign._id} data-testid={`campaign-row-${index}`}>
                        <TableCell>
                          <div>
                            <p className="font-medium text-foreground" data-testid={`campaign-name-${index}`}>
                              {campaign.name}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Domain: {campaign.template?.domain || 'N/A'}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={getStatusColor(campaign.status)} data-testid={`campaign-status-${index}`}>
                            {getStatusText(campaign.status)}
                          </Badge>
                        </TableCell>
                        <TableCell data-testid={`campaign-targets-${index}`}>
                          {campaign.targets?.totalCount || 0}
                        </TableCell>
                        <TableCell data-testid={`campaign-sent-${index}`}>
                          {campaign.tracking?.sent || 0}
                        </TableCell>
                        <TableCell data-testid={`campaign-opened-${index}`}>
                          <div>
                            <span>{campaign.tracking?.opened || 0}</span>
                            <span className="text-sm text-muted-foreground ml-1">
                              ({getOpenRate(campaign)})
                            </span>
                          </div>
                        </TableCell>
                        <TableCell data-testid={`campaign-clicked-${index}`}>
                          <div>
                            <span>{campaign.tracking?.clicked || 0}</span>
                            <span className="text-sm text-muted-foreground ml-1">
                              ({getClickRate(campaign)})
                            </span>
                          </div>
                        </TableCell>
                        <TableCell data-testid={`campaign-created-${index}`}>
                          {formatDate(campaign.createdAt)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditCampaign(campaign)}
                              data-testid={`view-campaign-${index}`}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        <CampaignModal 
          isOpen={campaignModalOpen}
          onClose={handleModalClose}
          campaign={selectedCampaign}
        />

      </div>
    </AppShell>
  );
}
