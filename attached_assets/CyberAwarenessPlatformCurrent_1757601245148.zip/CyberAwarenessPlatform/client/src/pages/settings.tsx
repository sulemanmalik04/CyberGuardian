import { useState } from 'react';
import { AppShell } from '@/components/layout/AppShell';
import { TopHeader } from '@/components/layout/TopHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { BrandingSettings } from '@/components/settings/BrandingSettings';
import { LanguageSettings } from '@/components/settings/LanguageSettings';
import { useAuth } from '@/hooks/useAuth';
import { 
  Settings as SettingsIcon, 
  Palette, 
  Globe, 
  Users, 
  Shield, 
  Mail, 
  Database,
  Key,
  Bell,
  Lock
} from 'lucide-react';

export default function Settings() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('branding');

  const settingsTabs = [
    {
      id: 'branding',
      label: 'Branding',
      icon: Palette,
      description: 'Customize platform appearance',
      adminOnly: true,
    },
    {
      id: 'language',
      label: 'Languages',
      icon: Globe,
      description: 'Multi-language settings',
      adminOnly: false,
    },
    {
      id: 'security',
      label: 'Security',
      icon: Shield,
      description: 'Security policies and settings',
      adminOnly: true,
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: Bell,
      description: 'Email and system notifications',
      adminOnly: false,
    },
    {
      id: 'integrations',
      label: 'Integrations',
      icon: Database,
      description: 'Third-party integrations',
      adminOnly: true,
    },
  ];

  const availableTabs = settingsTabs.filter(tab => 
    !tab.adminOnly || (user?.role === 'super_admin' || user?.role === 'client_admin')
  );

  const renderSecuritySettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold">Security Policies</h3>
        <p className="text-sm text-muted-foreground">
          Configure security settings and authentication policies
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lock className="w-5 h-5" />
              <span>Password Policy</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">Current Requirements:</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Minimum 8 characters</li>
                <li>• At least one uppercase letter</li>
                <li>• At least one number</li>
                <li>• Special characters recommended</li>
              </ul>
            </div>
            <Badge variant="secondary">Standard Policy</Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Key className="w-5 h-5" />
              <span>Session Management</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">Current Settings:</p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Session timeout: 7 days</li>
                <li>• Auto-logout on inactivity: 2 hours</li>
                <li>• Remember device: Enabled</li>
              </ul>
            </div>
            <Badge variant="default">Active</Badge>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>API Keys & Integrations</CardTitle>
          <p className="text-sm text-muted-foreground">
            Manage API keys for external services
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium">SendGrid API Key</p>
                <p className="text-sm text-muted-foreground">Email delivery service</p>
              </div>
              <Badge variant="default">Connected</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium">OpenAI API Key</p>
                <p className="text-sm text-muted-foreground">AI assistant and content generation</p>
              </div>
              <Badge variant="default">Connected</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <p className="font-medium">AWS S3 Storage</p>
                <p className="text-sm text-muted-foreground">File storage for logos and templates</p>
              </div>
              <Badge variant="secondary">Optional</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderNotificationSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold">Notification Preferences</h3>
        <p className="text-sm text-muted-foreground">
          Configure email and system notification settings
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Mail className="w-5 h-5" />
              <span>Email Notifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <div>
                  <p className="text-sm font-medium">Campaign Completion</p>
                  <p className="text-xs text-muted-foreground">When phishing campaigns complete</p>
                </div>
              </label>
              
              <label className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <div>
                  <p className="text-sm font-medium">User Registration</p>
                  <p className="text-xs text-muted-foreground">When new users join</p>
                </div>
              </label>
              
              <label className="flex items-center space-x-3">
                <input type="checkbox" className="rounded" />
                <div>
                  <p className="text-sm font-medium">Daily Summaries</p>
                  <p className="text-xs text-muted-foreground">Daily activity reports</p>
                </div>
              </label>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="w-5 h-5" />
              <span>System Alerts</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <div>
                  <p className="text-sm font-medium">Security Incidents</p>
                  <p className="text-xs text-muted-foreground">High-risk security events</p>
                </div>
              </label>
              
              <label className="flex items-center space-x-3">
                <input type="checkbox" defaultChecked className="rounded" />
                <div>
                  <p className="text-sm font-medium">System Maintenance</p>
                  <p className="text-xs text-muted-foreground">Planned maintenance windows</p>
                </div>
              </label>
              
              <label className="flex items-center space-x-3">
                <input type="checkbox" className="rounded" />
                <div>
                  <p className="text-sm font-medium">Feature Updates</p>
                  <p className="text-xs text-muted-foreground">New features and improvements</p>
                </div>
              </label>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  const renderIntegrationsSettings = () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold">Third-Party Integrations</h3>
        <p className="text-sm text-muted-foreground">
          Connect external services and configure integrations
        </p>
      </div>

      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Azure Active Directory</CardTitle>
            <p className="text-sm text-muted-foreground">
              Sync users from your Azure AD tenant
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Status: Not Connected</p>
                <p className="text-xs text-muted-foreground">Configure OAuth settings to enable</p>
              </div>
              <Badge variant="outline">Available</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>LDAP Integration</CardTitle>
            <p className="text-sm text-muted-foreground">
              Connect to your corporate LDAP directory
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Status: Not Configured</p>
                <p className="text-xs text-muted-foreground">Enterprise feature</p>
              </div>
              <Badge variant="secondary">Enterprise</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>SIEM Integration</CardTitle>
            <p className="text-sm text-muted-foreground">
              Send security events to your SIEM system
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Status: Available</p>
                <p className="text-xs text-muted-foreground">Configure webhook endpoints</p>
              </div>
              <Badge variant="outline">Available</Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );

  return (
    <AppShell>
      <TopHeader 
        title="Settings"
        subtitle="Configure platform settings and preferences"
      />
      
      <div className="p-6" data-testid="settings-page">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          
          {/* Tabs Navigation */}
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 gap-2">
            {availableTabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <TabsTrigger 
                  key={tab.id} 
                  value={tab.id}
                  className="flex items-center space-x-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                  data-testid={`${tab.id}-tab`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {/* Tab Content */}
          <div className="space-y-6">
            
            <TabsContent value="branding" className="space-y-0">
              <BrandingSettings />
            </TabsContent>

            <TabsContent value="language" className="space-y-0">
              <LanguageSettings />
            </TabsContent>

            <TabsContent value="security" className="space-y-0">
              {renderSecuritySettings()}
            </TabsContent>

            <TabsContent value="notifications" className="space-y-0">
              {renderNotificationSettings()}
            </TabsContent>

            <TabsContent value="integrations" className="space-y-0">
              {renderIntegrationsSettings()}
            </TabsContent>

          </div>
        </Tabs>
      </div>
    </AppShell>
  );
}
