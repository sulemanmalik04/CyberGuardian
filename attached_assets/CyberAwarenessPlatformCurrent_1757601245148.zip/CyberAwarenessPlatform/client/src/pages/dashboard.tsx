import { AppShell } from "@/components/layout/AppShell";
import { StatsCards } from "@/components/dashboard/StatsCards";
import { RecentCampaigns } from "@/components/dashboard/RecentCampaigns";
import { TrainingProgress } from "@/components/dashboard/TrainingProgress";
import { QuickActions } from "@/components/dashboard/QuickActions";

export default function Dashboard() {
  return (
    <AppShell>
      <div className="p-6 space-y-6" data-testid="dashboard-page">
        
        {/* Stats Cards */}
        <StatsCards />

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentCampaigns />
          <TrainingProgress />
        </div>
        
        {/* Quick Actions */}
        <QuickActions />
        
      </div>
    </AppShell>
  );
}
