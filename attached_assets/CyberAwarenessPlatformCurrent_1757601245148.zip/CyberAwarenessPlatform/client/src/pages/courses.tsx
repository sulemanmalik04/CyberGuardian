import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/AppShell";
import { TopHeader } from "@/components/layout/TopHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  BookOpen, 
  Clock, 
  Users, 
  Play, 
  Star,
  Filter,
  Plus,
  Eye,
  Edit,
  Trash2,
  Award,
  GraduationCap
} from "lucide-react";

export default function Courses() {
  const [searchQuery, setSearchQuery] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("all");
  const [languageFilter, setLanguageFilter] = useState<string>("all");
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: courses, isLoading } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: async () => {
      const response = await apiClient.getCourses();
      return response.data || [];
    },
  });

  const { data: users } = useQuery({
    queryKey: ['/api/users', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getUsers(user?.clientId);
      return response.data || [];
    },
    enabled: !!user?.clientId,
  });

  const generateQuizMutation = useMutation({
    mutationFn: async ({ courseContent, questionCount }: { courseContent: string; questionCount: number }) => {
      const response = await apiClient.generateQuiz(courseContent, questionCount);
      return response.data;
    },
    onSuccess: (data) => {
      toast({
        title: "Quiz Generated",
        description: `Generated ${data.questions?.length || 0} questions successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate quiz",
        variant: "destructive",
      });
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'default';
      case 'intermediate': return 'secondary';
      case 'advanced': return 'destructive';
      default: return 'outline';
    }
  };

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return <Star className="h-3 w-3" />;
      case 'intermediate': return <Award className="h-3 w-3" />;
      case 'advanced': return <GraduationCap className="h-3 w-3" />;
      default: return <BookOpen className="h-3 w-3" />;
    }
  };

  const calculateCourseProgress = (course: any) => {
    if (!users || users.length === 0) return { percentage: 0, completed: 0, total: 0 };
    
    // Simulate course-specific progress
    const baseCompletion = course.difficulty === 'beginner' ? 0.8 : 
                          course.difficulty === 'intermediate' ? 0.6 : 0.4;
    
    const completed = Math.floor(users.length * baseCompletion * (0.8 + Math.random() * 0.4));
    const percentage = users.length > 0 ? Math.round((completed / users.length) * 100) : 0;
    
    return { percentage, completed, total: users.length };
  };

  const filteredCourses = courses?.filter((course: any) => {
    const matchesSearch = 
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.tags?.some((tag: string) => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesDifficulty = difficultyFilter === "all" || course.difficulty === difficultyFilter;
    const matchesLanguage = languageFilter === "all" || course.language === languageFilter;

    return matchesSearch && matchesDifficulty && matchesLanguage;
  }) || [];

  const handleGenerateQuiz = (course: any) => {
    const courseContent = course.content?.map((c: any) => c.content).join('\n') || course.description;
    generateQuizMutation.mutate({ courseContent, questionCount: 5 });
  };

  const uniqueLanguages = [...new Set(courses?.map((c: any) => c.language).filter(Boolean))] || [];
  const courseStats = {
    total: courses?.length || 0,
    beginner: courses?.filter((c: any) => c.difficulty === 'beginner').length || 0,
    intermediate: courses?.filter((c: any) => c.difficulty === 'intermediate').length || 0,
    advanced: courses?.filter((c: any) => c.difficulty === 'advanced').length || 0,
    published: courses?.filter((c: any) => c.isPublished).length || 0,
  };

  return (
    <AppShell>
      <TopHeader 
        title="Training Courses"
        subtitle="Manage cybersecurity training content and assignments"
      />
      
      <div className="p-6 space-y-6" data-testid="courses-page">
        
        {/* Header Actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center space-x-4 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search courses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="search-courses"
              />
            </div>
            
            <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
              <SelectTrigger className="w-32" data-testid="difficulty-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>

            <Select value={languageFilter} onValueChange={setLanguageFilter}>
              <SelectTrigger className="w-32" data-testid="language-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Languages</SelectItem>
                {uniqueLanguages.map((lang: string) => (
                  <SelectItem key={lang} value={lang}>
                    {lang.toUpperCase()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {user?.role !== 'user' && (
            <Button data-testid="create-course-button">
              <Plus className="w-4 h-4 mr-2" />
              Create Course
            </Button>
          )}
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Courses</p>
                  <p className="text-2xl font-bold" data-testid="total-courses">
                    {courseStats.total}
                  </p>
                </div>
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Published</p>
                  <p className="text-2xl font-bold" data-testid="published-courses">
                    {courseStats.published}
                  </p>
                </div>
                <Play className="h-8 w-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Languages</p>
                  <p className="text-2xl font-bold" data-testid="total-languages">
                    {uniqueLanguages.length}
                  </p>
                </div>
                <Filter className="h-8 w-8 text-secondary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg. Duration</p>
                  <p className="text-2xl font-bold" data-testid="avg-duration">
                    {courses?.length > 0 
                      ? Math.round(courses.reduce((sum: number, c: any) => sum + (c.estimatedDuration || 0), 0) / courses.length) + 'm'
                      : '0m'
                    }
                  </p>
                </div>
                <Clock className="h-8 w-8 text-destructive" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Courses Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Available Courses ({filteredCourses.length})</h3>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="h-4 bg-muted rounded w-3/4"></div>
                      <div className="h-3 bg-muted rounded"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                      <div className="flex space-x-2">
                        <div className="h-6 bg-muted rounded w-16"></div>
                        <div className="h-6 bg-muted rounded w-12"></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredCourses.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {courses?.length === 0 ? "No courses available" : "No courses found"}
              </h3>
              <p className="text-muted-foreground mb-4">
                {courses?.length === 0 
                  ? "Courses will be available once the content library is set up"
                  : "Try adjusting your search criteria or filters"
                }
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course: any, index: number) => {
                const progress = calculateCourseProgress(course);
                
                return (
                  <Card key={course._id} className="hover-lift group" data-testid={`course-card-${index}`}>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {/* Course Header */}
                        <div className="space-y-2">
                          <div className="flex items-start justify-between">
                            <h3 className="font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors" data-testid={`course-title-${index}`}>
                              {course.title}
                            </h3>
                            {course.isPublished && (
                              <Badge variant="default" className="ml-2 flex-shrink-0">
                                Published
                              </Badge>
                            )}
                          </div>
                          
                          <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`course-description-${index}`}>
                            {course.description}
                          </p>
                        </div>

                        {/* Course Meta */}
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{course.estimatedDuration || 30} mins</span>
                          </div>
                          
                          <div className="flex items-center space-x-1">
                            <Users className="h-4 w-4" />
                            <span>{progress.completed}/{progress.total}</span>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Completion Rate</span>
                            <span className="font-medium">{progress.percentage}%</span>
                          </div>
                          <Progress value={progress.percentage} className="h-2" />
                        </div>

                        {/* Tags and Difficulty */}
                        <div className="flex items-center justify-between">
                          <div className="flex flex-wrap gap-1">
                            <Badge 
                              variant={getDifficultyColor(course.difficulty)}
                              className="text-xs"
                              data-testid={`course-difficulty-${index}`}
                            >
                              <span className="mr-1">{getDifficultyIcon(course.difficulty)}</span>
                              {course.difficulty}
                            </Badge>
                            
                            <Badge variant="outline" className="text-xs">
                              {course.language?.toUpperCase() || 'EN'}
                            </Badge>

                            {course.tags?.slice(0, 1).map((tag: string, tagIndex: number) => (
                              <Badge key={tagIndex} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center space-x-2 pt-2">
                          <Button 
                            size="sm" 
                            className="flex-1"
                            data-testid={`start-course-${index}`}
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Start Course
                          </Button>

                          {user?.role !== 'user' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleGenerateQuiz(course)}
                              disabled={generateQuizMutation.isPending}
                              data-testid={`generate-quiz-${index}`}
                            >
                              <GraduationCap className="h-4 w-4" />
                            </Button>
                          )}

                          <Button
                            size="sm"
                            variant="ghost"
                            data-testid={`view-course-${index}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>

      </div>
    </AppShell>
  );
}
