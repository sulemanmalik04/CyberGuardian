export const chartColors = {
  primary: 'hsl(214, 95%, 43%)',
  secondary: 'hsl(215, 13%, 34%)',
  accent: 'hsl(158, 74%, 36%)',
  destructive: 'hsl(0, 84%, 60%)',
  muted: 'hsl(210, 40%, 96%)',
  success: 'hsl(142, 76%, 36%)',
  warning: 'hsl(38, 92%, 50%)',
  info: 'hsl(199, 89%, 48%)',
};

export const defaultChartConfig = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
      labels: {
        usePointStyle: true,
        padding: 20,
      },
    },
    tooltip: {
      backgroundColor: 'hsl(0, 0%, 100%)',
      titleColor: 'hsl(222.2, 84%, 4.9%)',
      bodyColor: 'hsl(222.2, 84%, 4.9%)',
      borderColor: 'hsl(214.3, 31.8%, 91.4%)',
      borderWidth: 1,
      cornerRadius: 8,
      padding: 12,
    },
  },
  scales: {
    x: {
      grid: {
        display: false,
      },
      ticks: {
        color: 'hsl(215.4, 16.3%, 46.9%)',
      },
    },
    y: {
      grid: {
        color: 'hsl(214.3, 31.8%, 91.4%)',
      },
      ticks: {
        color: 'hsl(215.4, 16.3%, 46.9%)',
      },
    },
  },
};
