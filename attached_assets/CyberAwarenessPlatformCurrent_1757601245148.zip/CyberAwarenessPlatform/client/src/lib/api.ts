import { apiRequest } from "./queryClient";
import { DashboardStats } from "@shared/schema";

export interface ApiResponse<T = any> {
  data?: T;
  message?: string;
  success: boolean;
}

export class ApiClient {
  private getAuthHeaders(): Record<string, string> {
    const token = localStorage.getItem('auth_token');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  }

  async request<T>(
    method: string,
    url: string,
    data?: unknown
  ): Promise<ApiResponse<T>> {
    try {
      const response = await fetch(url, {
        method,
        headers: {
          ...this.getAuthHeaders(),
          ...(data ? { 'Content-Type': 'application/json' } : {}),
        },
        body: data ? JSON.stringify(data) : undefined,
      });

      const responseData = await response.json();

      return {
        data: responseData,
        success: response.ok,
        message: responseData.message,
      };
    } catch (error) {
      console.error('API request error:', error);
      return {
        success: false,
        message: 'Network error occurred',
      };
    }
  }

  // User management
  async getUsers(clientId?: string) {
    const url = clientId ? `/api/users?clientId=${clientId}` : '/api/users';
    return this.request('GET', url);
  }

  async createUser(userData: any) {
    return this.request('POST', '/api/users', userData);
  }

  async updateUser(id: string, updates: any) {
    return this.request('PUT', `/api/users/${id}`, updates);
  }

  async deleteUser(id: string) {
    return this.request('DELETE', `/api/users/${id}`);
  }

  // Client management
  async getClients() {
    return this.request('GET', '/api/clients');
  }

  async createClient(clientData: any) {
    return this.request('POST', '/api/clients', clientData);
  }

  async updateClient(id: string, updates: any) {
    return this.request('PUT', `/api/clients/${id}`, updates);
  }

  // Course management
  async getCourses(language?: string) {
    const url = language ? `/api/courses?language=${language}` : '/api/courses';
    return this.request('GET', url);
  }

  async createCourse(courseData: any) {
    return this.request('POST', '/api/courses', courseData);
  }

  async updateCourse(id: string, updates: any) {
    return this.request('PUT', `/api/courses/${id}`, updates);
  }

  // Campaign management
  async getCampaigns(clientId?: string) {
    const url = clientId ? `/api/campaigns?clientId=${clientId}` : '/api/campaigns';
    return this.request('GET', url);
  }

  async createCampaign(campaignData: any) {
    return this.request('POST', '/api/campaigns', campaignData);
  }

  async launchCampaign(id: string) {
    return this.request('POST', `/api/campaigns/${id}/launch`);
  }

  // Analytics
  async getAnalytics(filters: any = {}) {
    const params = new URLSearchParams(filters);
    return this.request('GET', `/api/analytics?${params}`);
  }

  async getDashboardStats(clientId?: string) {
    const url = clientId ? `/api/dashboard/stats?clientId=${clientId}` : '/api/dashboard/stats';
    return this.request<DashboardStats>('GET', url);
  }

  // AI Assistant
  async chatWithAI(messages: any[], context?: any) {
    return this.request('POST', '/api/ai/chat', { messages, context });
  }

  async generateQuiz(courseContent: string, questionCount: number = 5) {
    return this.request('POST', '/api/ai/generate-quiz', { courseContent, questionCount });
  }

  async getRecommendations(userPerformance: any) {
    return this.request('POST', '/api/ai/recommendations', { userPerformance });
  }

  async generatePhishingContent(templateType: string, targetAudience: string) {
    return this.request('POST', '/api/ai/generate-phishing', { templateType, targetAudience });
  }
}

export const apiClient = new ApiClient();
