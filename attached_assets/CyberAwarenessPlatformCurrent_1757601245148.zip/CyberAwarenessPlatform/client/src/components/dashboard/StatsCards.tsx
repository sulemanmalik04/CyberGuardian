import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Mail, GraduationCap, Shield } from "lucide-react";

export function StatsCards() {
  const { user } = useAuth();
  
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/dashboard/stats', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getDashboardStats(user?.clientId);
      return response.data;
    },
  });

  if (isLoading) {
    return (
      <div className="dashboard-grid">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="hover-lift">
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-muted rounded w-20 mb-2"></div>
                <div className="h-8 bg-muted rounded w-16 mb-2"></div>
                <div className="h-3 bg-muted rounded w-24"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      title: "Active Users",
      value: stats?.activeUsers || 0,
      change: "+12% from last month",
      icon: Users,
      color: "primary",
      changeType: "positive",
    },
    {
      title: "Campaigns Sent", 
      value: stats?.campaignsSent || 0,
      change: "+5 this week",
      icon: Mail,
      color: "accent",
      changeType: "positive",
    },
    {
      title: "Training Completion",
      value: `${stats?.completionRate || 0}%`,
      change: "-2.1% from target",
      icon: GraduationCap,
      color: "destructive",
      changeType: "negative",
    },
    {
      title: "Security Score",
      value: stats?.securityScore || 0,
      change: "+8 points improved",
      icon: Shield,
      color: "accent",
      changeType: "positive",
    },
  ];

  return (
    <div className="dashboard-grid">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card key={index} className="hover-lift" data-testid={`stat-card-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </p>
                  <p className="text-3xl font-bold text-foreground" data-testid={`stat-value-${index}`}>
                    {typeof stat.value === 'number' ? stat.value.toLocaleString() : stat.value}
                  </p>
                  <p className={`text-sm ${
                    stat.changeType === 'positive' ? 'text-accent' : 'text-destructive'
                  }`}>
                    {stat.change}
                  </p>
                </div>
                <div className={`w-12 h-12 bg-${stat.color}/10 rounded-lg flex items-center justify-center`}>
                  <Icon className={`text-${stat.color} w-6 h-6`} />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
