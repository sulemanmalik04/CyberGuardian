import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export function RecentCampaigns() {
  const { user } = useAuth();
  
  const { data: campaigns, isLoading } = useQuery({
    queryKey: ['/api/campaigns', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getCampaigns(user?.clientId);
      return response.data || [];
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'accent';
      case 'sending': return 'primary';
      case 'scheduled': return 'secondary';
      default: return 'muted';
    }
  };

  const getStatusDot = (status: string) => {
    const color = getStatusColor(status);
    return <div className={`w-2 h-2 bg-${color} rounded-full`} />;
  };

  const getClickRate = (campaign: any) => {
    if (!campaign.tracking.sent) return '0%';
    return `${Math.round((campaign.tracking.clicked / campaign.tracking.sent) * 100)}%`;
  };

  const getTimeAgo = (date: string) => {
    const now = new Date();
    const created = new Date(date);
    const diffHours = Math.floor((now.getTime() - created.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours} hours ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} days ago`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-muted rounded-full"></div>
                    <div>
                      <div className="h-4 bg-muted rounded w-32 mb-1"></div>
                      <div className="h-3 bg-muted rounded w-24"></div>
                    </div>
                  </div>
                  <div>
                    <div className="h-4 bg-muted rounded w-16 mb-1"></div>
                    <div className="h-3 bg-muted rounded w-12"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const recentCampaigns = campaigns
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  return (
    <Card data-testid="recent-campaigns-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Campaigns</CardTitle>
          <Link href="/campaigns">
            <Button variant="ghost" size="sm" data-testid="view-all-campaigns">
              View All
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentCampaigns.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No campaigns yet</p>
              <Link href="/campaigns">
                <Button className="mt-2" data-testid="create-first-campaign">
                  Create Your First Campaign
                </Button>
              </Link>
            </div>
          ) : (
            recentCampaigns.map((campaign: any, index: number) => (
              <div 
                key={campaign._id} 
                className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors"
                data-testid={`campaign-${index}`}
              >
                <div className="flex items-center space-x-3">
                  {getStatusDot(campaign.status)}
                  <div>
                    <p className="text-sm font-medium text-foreground" data-testid={`campaign-name-${index}`}>
                      {campaign.name}
                    </p>
                    <p className="text-xs text-muted-foreground" data-testid={`campaign-targets-${index}`}>
                      Sent to {campaign.targets.totalCount} users
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-foreground" data-testid={`campaign-click-rate-${index}`}>
                    {getClickRate(campaign)} clicked
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid={`campaign-time-${index}`}>
                    {getTimeAgo(campaign.createdAt)}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
