import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Upload, BookOpen, BarChart } from "lucide-react";
import { CampaignModal } from "@/components/modals/CampaignModal";
import { UserImportModal } from "@/components/modals/UserImportModal";
import { Link } from "wouter";

export function QuickActions() {
  const [campaignModalOpen, setCampaignModalOpen] = useState(false);
  const [userImportModalOpen, setUserImportModalOpen] = useState(false);

  const quickActions = [
    {
      title: "New Campaign",
      description: "Launch phishing simulation",
      icon: Plus,
      color: "primary",
      action: () => setCampaignModalOpen(true),
      testId: "create-campaign",
    },
    {
      title: "Import Users", 
      description: "CSV or Azure AD sync",
      icon: Upload,
      color: "accent",
      action: () => setUserImportModalOpen(true),
      testId: "import-users",
    },
    {
      title: "Assign Courses",
      description: "Manage training assignments", 
      icon: BookOpen,
      color: "secondary",
      href: "/courses",
      testId: "assign-courses",
    },
    {
      title: "View Reports",
      description: "Analytics & insights",
      icon: BarChart,
      color: "destructive", 
      href: "/analytics",
      testId: "view-reports",
    },
  ];

  return (
    <>
      <Card data-testid="quick-actions-card">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              
              const ActionButton = (
                <Button
                  variant="ghost"
                  className={`flex items-center space-x-3 p-4 h-auto bg-${action.color}/5 hover:bg-${action.color}/10 transition-colors text-left justify-start w-full`}
                  onClick={action.action}
                  data-testid={action.testId}
                >
                  <div className={`w-10 h-10 bg-${action.color}/20 rounded-lg flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`text-${action.color} w-5 h-5`} />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-foreground">{action.title}</p>
                    <p className="text-sm text-muted-foreground">{action.description}</p>
                  </div>
                </Button>
              );

              if (action.href) {
                return (
                  <Link key={index} href={action.href}>
                    {ActionButton}
                  </Link>
                );
              }

              return ActionButton;
            })}
          </div>
        </CardContent>
      </Card>

      <CampaignModal 
        isOpen={campaignModalOpen} 
        onClose={() => setCampaignModalOpen(false)} 
      />
      
      <UserImportModal 
        isOpen={userImportModalOpen} 
        onClose={() => setUserImportModalOpen(false)} 
      />
    </>
  );
}
