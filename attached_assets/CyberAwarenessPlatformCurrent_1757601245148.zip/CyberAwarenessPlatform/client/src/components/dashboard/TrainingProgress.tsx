import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";

export function TrainingProgress() {
  const { user } = useAuth();
  
  const { data: courses, isLoading } = useQuery({
    queryKey: ['/api/courses', user?.language],
    queryFn: async () => {
      const response = await apiClient.getCourses(user?.language);
      return response.data || [];
    },
  });

  const { data: users } = useQuery({
    queryKey: ['/api/users', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getUsers(user?.clientId);
      return response.data || [];
    },
    enabled: !!user?.clientId,
  });

  const calculateProgress = (course: any) => {
    if (!users || users.length === 0) return { percentage: 0, completed: 0, total: 0 };
    
    const usersWithProgress = users.filter((u: any) => 
      u.progress?.coursesCompleted > 0
    );
    
    // Simulate course-specific progress based on course difficulty
    const baseCompletion = course.difficulty === 'beginner' ? 0.8 : 
                          course.difficulty === 'intermediate' ? 0.6 : 0.4;
    
    const completed = Math.floor(users.length * baseCompletion * (0.8 + Math.random() * 0.4));
    const percentage = users.length > 0 ? Math.round((completed / users.length) * 100) : 0;
    
    return { percentage, completed, total: users.length };
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Training Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-2 animate-pulse">
                <div className="flex justify-between">
                  <div className="h-4 bg-muted rounded w-32"></div>
                  <div className="h-4 bg-muted rounded w-8"></div>
                </div>
                <div className="h-2 bg-muted rounded"></div>
                <div className="h-3 bg-muted rounded w-24"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const topCourses = courses.slice(0, 3);

  return (
    <Card data-testid="training-progress-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Training Progress</CardTitle>
          <Link href="/courses">
            <Button variant="ghost" size="sm" data-testid="view-training-details">
              View Details
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {topCourses.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No courses available</p>
              <Link href="/courses">
                <Button className="mt-2" data-testid="browse-courses">
                  Browse Courses
                </Button>
              </Link>
            </div>
          ) : (
            topCourses.map((course: any, index: number) => {
              const progress = calculateProgress(course);
              
              return (
                <div key={course._id} className="space-y-2" data-testid={`course-progress-${index}`}>
                  <div className="flex justify-between text-sm">
                    <span className="text-foreground font-medium" data-testid={`course-title-${index}`}>
                      {course.title}
                    </span>
                    <span className="text-muted-foreground" data-testid={`course-percentage-${index}`}>
                      {progress.percentage}%
                    </span>
                  </div>
                  <Progress 
                    value={progress.percentage} 
                    className="h-2"
                    data-testid={`course-progress-bar-${index}`}
                  />
                  <p className="text-xs text-muted-foreground" data-testid={`course-completion-stats-${index}`}>
                    {progress.completed} of {progress.total} users completed
                  </p>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
