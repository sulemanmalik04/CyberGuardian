import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import { 
  Shield, 
  BarChart3, 
  Mail, 
  Users, 
  GraduationCap, 
  TrendingUp, 
  Settings, 
  LogOut,
  User
} from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navigation = [
    { name: "Dashboard", href: "/dashboard", icon: BarChart3 },
    { name: "Phishing Campaigns", href: "/campaigns", icon: Mail },
    { name: "User Management", href: "/users", icon: Users },
    { name: "Training Courses", href: "/courses", icon: GraduationCap },
    { name: "Analytics & Reports", href: "/analytics", icon: TrendingUp },
    { name: "Settings", href: "/settings", icon: Settings },
  ];

  const handleLinkClick = () => {
    onClose();
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden"
          onClick={onClose}
          data-testid="sidebar-overlay"
        />
      )}
      
      {/* Sidebar */}
      <aside 
        className={cn(
          "sidebar-transition w-64 bg-sidebar border-r border-sidebar-border flex flex-col shadow-sm",
          "fixed inset-y-0 left-0 z-50 md:relative md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
        data-testid="sidebar"
      >
        {/* Logo section */}
        <div className="p-6 border-b border-sidebar-border">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-sidebar-primary rounded-lg flex items-center justify-center">
              <Shield className="text-sidebar-primary-foreground w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-sidebar-foreground" data-testid="client-name">
                CyberSecure Platform
              </h1>
              <p className="text-xs text-muted-foreground">Training & Awareness</p>
            </div>
          </div>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={handleLinkClick}
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors",
                  isActive
                    ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium"
                    : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground"
                )}
                data-testid={`nav-${item.href.replace('/', '')}`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>
        
        {/* User section */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="flex items-center space-x-3 px-3 py-2">
            <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
              <User className="text-secondary-foreground w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate" data-testid="user-name">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-xs text-muted-foreground truncate" data-testid="user-role">
                {user?.role === 'super_admin' ? 'Super Administrator' : 
                 user?.role === 'client_admin' ? 'Client Administrator' : 'User'}
              </p>
            </div>
            <button 
              className="text-muted-foreground hover:text-sidebar-foreground transition-colors"
              onClick={logout}
              data-testid="logout-button"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
