import { useState } from "react";
import { Menu, Bell, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AIAssistantModal } from "@/components/modals/AIAssistantModal";

interface TopHeaderProps {
  onMenuClick: () => void;
  title?: string;
  subtitle?: string;
}

export function TopHeader({ 
  onMenuClick, 
  title = "Dashboard Overview", 
  subtitle = "Manage your cybersecurity training programs" 
}: TopHeaderProps) {
  const [aiModalOpen, setAiModalOpen] = useState(false);

  return (
    <>
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={onMenuClick}
            data-testid="menu-button"
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground" data-testid="page-title">
              {title}
            </h1>
            <p className="text-sm text-muted-foreground" data-testid="page-subtitle">
              {subtitle}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative"
            data-testid="notifications-button"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-destructive rounded-full" />
          </Button>
          
          {/* AI Assistant */}
          <Button
            onClick={() => setAiModalOpen(true)}
            className="bg-accent text-accent-foreground hover:opacity-90 transition-opacity font-medium"
            data-testid="ai-assistant-button"
          >
            <Bot className="w-4 h-4 mr-2" />
            AI Assistant
          </Button>
        </div>
      </header>

      <AIAssistantModal 
        isOpen={aiModalOpen} 
        onClose={() => setAiModalOpen(false)} 
      />
    </>
  );
}
