import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { apiClient } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Languages, Globe, Users, BookOpen, Save } from 'lucide-react';

const supportedLanguages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
];

export function LanguageSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [defaultLanguage, setDefaultLanguage] = useState('en');
  const [bulkLanguageUpdate, setBulkLanguageUpdate] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  const { data: users } = useQuery({
    queryKey: ['/api/users', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getUsers(user?.clientId);
      return response.data || [];
    },
    enabled: user?.role !== 'user',
  });

  const { data: courses } = useQuery({
    queryKey: ['/api/courses'],
    queryFn: async () => {
      const response = await apiClient.getCourses();
      return response.data || [];
    },
  });

  const updateUserLanguageMutation = useMutation({
    mutationFn: async ({ userId, language }: { userId: string; language: string }) => {
      const response = await apiClient.updateUser(userId, { language });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: 'Language Updated',
        description: 'User language preference updated successfully',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update user language',
        variant: 'destructive',
      });
    },
  });

  const bulkUpdateLanguageMutation = useMutation({
    mutationFn: async ({ userIds, language }: { userIds: string[]; language: string }) => {
      const results = [];
      for (const userId of userIds) {
        const response = await apiClient.updateUser(userId, { language });
        results.push(response);
      }
      return results;
    },
    onSuccess: (results) => {
      const successful = results.filter(r => r.success).length;
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: 'Bulk Update Complete',
        description: `Updated language for ${successful} users`,
      });
      setSelectedUsers([]);
      setBulkLanguageUpdate('');
    },
    onError: (error: any) => {
      toast({
        title: 'Bulk Update Failed',
        description: error.message || 'Failed to update user languages',
        variant: 'destructive',
      });
    },
  });

  const handleUserLanguageChange = (userId: string, language: string) => {
    updateUserLanguageMutation.mutate({ userId, language });
  };

  const handleBulkUpdate = () => {
    if (selectedUsers.length === 0 || !bulkLanguageUpdate) {
      toast({
        title: 'Selection Required',
        description: 'Please select users and a language for bulk update',
        variant: 'destructive',
      });
      return;
    }
    
    bulkUpdateLanguageMutation.mutate({
      userIds: selectedUsers,
      language: bulkLanguageUpdate,
    });
  };

  const toggleUserSelection = (userId: string) => {
    setSelectedUsers(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const selectAllUsers = () => {
    if (selectedUsers.length === users?.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(users?.map((u: any) => u._id) || []);
    }
  };

  const getLanguageStats = () => {
    if (!users) return {};
    
    const stats: Record<string, number> = {};
    users.forEach((user: any) => {
      const lang = user.language || 'en';
      stats[lang] = (stats[lang] || 0) + 1;
    });
    
    return stats;
  };

  const getCourseLanguageStats = () => {
    if (!courses) return {};
    
    const stats: Record<string, number> = {};
    courses.forEach((course: any) => {
      const lang = course.language || 'en';
      stats[lang] = (stats[lang] || 0) + 1;
    });
    
    return stats;
  };

  const languageStats = getLanguageStats();
  const courseLanguageStats = getCourseLanguageStats();

  if (user?.role === 'user') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Language Preferences</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Your Language</label>
              <Select 
                value={user.language || 'en'} 
                onValueChange={(language) => handleUserLanguageChange(user._id!, language)}
              >
                <SelectTrigger className="mt-2" data-testid="user-language-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {supportedLanguages.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      <span className="flex items-center space-x-2">
                        <span>{lang.flag}</span>
                        <span>{lang.name}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6" data-testid="language-settings">
      
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold">Multi-Language Support</h3>
        <p className="text-sm text-muted-foreground">
          Manage language preferences for users and content localization
        </p>
      </div>

      {/* Language Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">User Languages</p>
                <p className="text-2xl font-bold">{Object.keys(languageStats).length}</p>
              </div>
              <Users className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Course Languages</p>
                <p className="text-2xl font-bold">{Object.keys(courseLanguageStats).length}</p>
              </div>
              <BookOpen className="h-8 w-8 text-accent" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Supported Languages</p>
                <p className="text-2xl font-bold">{supportedLanguages.length}</p>
              </div>
              <Globe className="h-8 w-8 text-secondary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Language Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>Language Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-medium mb-2">User Languages</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(languageStats).map(([langCode, count]) => {
                  const lang = supportedLanguages.find(l => l.code === langCode);
                  return (
                    <Badge key={langCode} variant="secondary" className="text-sm">
                      {lang?.flag} {lang?.name || langCode.toUpperCase()} ({count})
                    </Badge>
                  );
                })}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-2">Course Languages</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(courseLanguageStats).map(([langCode, count]) => {
                  const lang = supportedLanguages.find(l => l.code === langCode);
                  return (
                    <Badge key={langCode} variant="outline" className="text-sm">
                      {lang?.flag} {lang?.name || langCode.toUpperCase()} ({count} courses)
                    </Badge>
                  );
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bulk Language Update */}
      {users && users.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Bulk Language Assignment</CardTitle>
            <p className="text-sm text-muted-foreground">
              Update language preferences for multiple users at once
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="flex-1">
                  <Select value={bulkLanguageUpdate} onValueChange={setBulkLanguageUpdate}>
                    <SelectTrigger data-testid="bulk-language-select">
                      <SelectValue placeholder="Select language for bulk update" />
                    </SelectTrigger>
                    <SelectContent>
                      {supportedLanguages.map((lang) => (
                        <SelectItem key={lang.code} value={lang.code}>
                          <span className="flex items-center space-x-2">
                            <span>{lang.flag}</span>
                            <span>{lang.name}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleBulkUpdate}
                  disabled={selectedUsers.length === 0 || !bulkLanguageUpdate || bulkUpdateLanguageMutation.isPending}
                  data-testid="apply-bulk-update"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Update {selectedUsers.length} Users
                </Button>
              </div>

              <div className="text-sm text-muted-foreground">
                {selectedUsers.length > 0 ? (
                  <span>{selectedUsers.length} users selected</span>
                ) : (
                  <span>Select users from the table below</span>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* User Language Management Table */}
      {users && users.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>User Language Assignments</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedUsers.length === users.length}
                      onChange={selectAllUsers}
                      className="rounded"
                      data-testid="select-all-users"
                    />
                  </TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Current Language</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.slice(0, 10).map((user: any, index: number) => {
                  const userLanguage = supportedLanguages.find(l => l.code === (user.language || 'en'));
                  
                  return (
                    <TableRow key={user._id} data-testid={`user-language-row-${index}`}>
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={selectedUsers.includes(user._id)}
                          onChange={() => toggleUserSelection(user._id)}
                          className="rounded"
                          data-testid={`select-user-${index}`}
                        />
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{user.firstName} {user.lastName}</p>
                          <p className="text-sm text-muted-foreground">{user.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>{user.department || '-'}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {userLanguage?.flag} {userLanguage?.name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={user.language || 'en'}
                          onValueChange={(language) => handleUserLanguageChange(user._id, language)}
                        >
                          <SelectTrigger className="w-40" data-testid={`language-select-${index}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {supportedLanguages.map((lang) => (
                              <SelectItem key={lang.code} value={lang.code}>
                                <span className="flex items-center space-x-2">
                                  <span>{lang.flag}</span>
                                  <span>{lang.name}</span>
                                </span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>

            {users.length > 10 && (
              <div className="text-center py-4">
                <p className="text-sm text-muted-foreground">
                  Showing 10 of {users.length} users. Use bulk update for efficiency.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

    </div>
  );
}
