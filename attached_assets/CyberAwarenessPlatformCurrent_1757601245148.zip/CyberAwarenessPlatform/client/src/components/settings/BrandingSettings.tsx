import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { apiClient } from '@/lib/api';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Upload, Palette, Eye, Save, RotateCcw } from 'lucide-react';

export function BrandingSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [brandingData, setBrandingData] = useState({
    primaryColor: '#2563eb',
    secondaryColor: '#475569',
    logo: '',
    customCss: '',
  });

  const [previewMode, setPreviewMode] = useState(false);

  const { data: client } = useQuery({
    queryKey: ['/api/clients', user?.clientId],
    queryFn: async () => {
      if (user?.clientId) {
        const response = await apiClient.request('GET', `/api/clients/${user.clientId}`);
        return response.data;
      }
      return null;
    },
    enabled: !!user?.clientId && user?.role !== 'user',
    onSuccess: (data) => {
      if (data?.branding) {
        setBrandingData({
          primaryColor: data.branding.primaryColor || '#2563eb',
          secondaryColor: data.branding.secondaryColor || '#475569',
          logo: data.branding.logo || '',
          customCss: data.branding.customCss || '',
        });
      }
    },
  });

  const updateBrandingMutation = useMutation({
    mutationFn: async (updates: any) => {
      const response = await apiClient.updateClient(user?.clientId!, {
        branding: updates,
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clients'] });
      toast({
        title: 'Branding Updated',
        description: 'Your branding settings have been saved successfully',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update branding settings',
        variant: 'destructive',
      });
    },
  });

  const handleSave = () => {
    updateBrandingMutation.mutate(brandingData);
  };

  const handleReset = () => {
    setBrandingData({
      primaryColor: '#2563eb',
      secondaryColor: '#475569',
      logo: '',
      customCss: '',
    });
  };

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // In a real implementation, this would upload to S3 and return the URL
      const reader = new FileReader();
      reader.onload = (e) => {
        setBrandingData(prev => ({
          ...prev,
          logo: e.target?.result as string,
        }));
      };
      reader.readAsDataURL(file);
      
      toast({
        title: 'Logo Uploaded',
        description: 'Logo preview updated. Click Save to apply changes.',
      });
    }
  };

  const applyPreviewStyles = () => {
    if (previewMode) {
      document.documentElement.style.setProperty('--primary', brandingData.primaryColor);
      document.documentElement.style.setProperty('--secondary', brandingData.secondaryColor);
      
      if (brandingData.customCss) {
        const styleElement = document.getElementById('preview-styles') || document.createElement('style');
        styleElement.id = 'preview-styles';
        styleElement.textContent = brandingData.customCss;
        document.head.appendChild(styleElement);
      }
    } else {
      // Reset to original styles
      document.documentElement.style.removeProperty('--primary');
      document.documentElement.style.removeProperty('--secondary');
      const styleElement = document.getElementById('preview-styles');
      if (styleElement) {
        styleElement.remove();
      }
    }
  };

  const togglePreview = () => {
    setPreviewMode(!previewMode);
    setTimeout(applyPreviewStyles, 0);
  };

  if (user?.role === 'user') {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">
            Branding settings are only available to administrators.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6" data-testid="branding-settings">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Brand Customization</h3>
          <p className="text-sm text-muted-foreground">
            Customize your platform's appearance and branding
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={togglePreview}
            data-testid="toggle-preview"
          >
            <Eye className="w-4 h-4 mr-2" />
            {previewMode ? 'Exit Preview' : 'Preview Changes'}
          </Button>
          
          {previewMode && (
            <Badge variant="secondary">Preview Mode</Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Logo Upload */}
        <Card>
          <CardHeader>
            <CardTitle>Company Logo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              {brandingData.logo ? (
                <div className="space-y-4">
                  <img
                    src={brandingData.logo}
                    alt="Company Logo"
                    className="max-h-20 mx-auto"
                    data-testid="logo-preview"
                  />
                  <p className="text-sm text-muted-foreground">Current logo</p>
                </div>
              ) : (
                <div className="border-2 border-dashed border-muted rounded-lg p-8">
                  <Upload className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">No logo uploaded</p>
                </div>
              )}
            </div>
            
            <div>
              <Label htmlFor="logo-upload">Upload New Logo</Label>
              <Input
                id="logo-upload"
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="mt-2"
                data-testid="logo-upload"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Recommended: PNG or SVG format, max 500KB
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Color Scheme */}
        <Card>
          <CardHeader>
            <CardTitle>Color Scheme</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="primary-color">Primary Color</Label>
              <div className="flex items-center space-x-3 mt-2">
                <Input
                  id="primary-color"
                  type="color"
                  value={brandingData.primaryColor}
                  onChange={(e) => setBrandingData(prev => ({
                    ...prev,
                    primaryColor: e.target.value
                  }))}
                  className="w-16 h-10 p-1 rounded cursor-pointer"
                  data-testid="primary-color"
                />
                <Input
                  type="text"
                  value={brandingData.primaryColor}
                  onChange={(e) => setBrandingData(prev => ({
                    ...prev,
                    primaryColor: e.target.value
                  }))}
                  className="flex-1"
                  placeholder="#2563eb"
                  data-testid="primary-color-text"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="secondary-color">Secondary Color</Label>
              <div className="flex items-center space-x-3 mt-2">
                <Input
                  id="secondary-color"
                  type="color"
                  value={brandingData.secondaryColor}
                  onChange={(e) => setBrandingData(prev => ({
                    ...prev,
                    secondaryColor: e.target.value
                  }))}
                  className="w-16 h-10 p-1 rounded cursor-pointer"
                  data-testid="secondary-color"
                />
                <Input
                  type="text"
                  value={brandingData.secondaryColor}
                  onChange={(e) => setBrandingData(prev => ({
                    ...prev,
                    secondaryColor: e.target.value
                  }))}
                  className="flex-1"
                  placeholder="#475569"
                  data-testid="secondary-color-text"
                />
              </div>
            </div>

            {/* Color Preview */}
            <div className="space-y-2">
              <Label>Color Preview</Label>
              <div className="flex items-center space-x-2">
                <div 
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: brandingData.primaryColor }}
                  data-testid="primary-color-preview"
                />
                <div 
                  className="w-8 h-8 rounded border"
                  style={{ backgroundColor: brandingData.secondaryColor }}
                  data-testid="secondary-color-preview"
                />
                <span className="text-sm text-muted-foreground">
                  Primary & Secondary
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Custom CSS */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Custom CSS</CardTitle>
            <p className="text-sm text-muted-foreground">
              Add custom styles to further customize your platform appearance
            </p>
          </CardHeader>
          <CardContent>
            <Textarea
              value={brandingData.customCss}
              onChange={(e) => setBrandingData(prev => ({
                ...prev,
                customCss: e.target.value
              }))}
              placeholder="/* Add your custom CSS here */
.custom-header {
  background: linear-gradient(45deg, var(--primary), var(--secondary));
}

.custom-button {
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}"
              className="min-h-[200px] font-mono text-sm"
              data-testid="custom-css"
            />
            <p className="text-xs text-muted-foreground mt-2">
              Use CSS variables: var(--primary), var(--secondary), var(--background), etc.
            </p>
          </CardContent>
        </Card>

      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-end space-x-3">
        <Button
          variant="outline"
          onClick={handleReset}
          data-testid="reset-branding"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset to Default
        </Button>
        
        <Button
          onClick={handleSave}
          disabled={updateBrandingMutation.isPending}
          data-testid="save-branding"
        >
          <Save className="w-4 h-4 mr-2" />
          {updateBrandingMutation.isPending ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>

    </div>
  );
}
