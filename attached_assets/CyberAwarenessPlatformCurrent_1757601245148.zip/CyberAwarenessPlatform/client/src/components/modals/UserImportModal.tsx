import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { X, FileText, Upload, Download } from "lucide-react";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface UserImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserImportModal({ isOpen, onClose }: UserImportModalProps) {
  const [importMethod, setImportMethod] = useState<"csv" | "azure" | null>(null);
  const [defaultLanguage, setDefaultLanguage] = useState("en");
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvData, setCsvData] = useState<any[]>([]);
  const [importPreview, setImportPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  const languages = [
    { code: "en", name: "English" },
    { code: "es", name: "Spanish" },
    { code: "fr", name: "French" },
    { code: "de", name: "German" },
    { code: "it", name: "Italian" },
    { code: "pt", name: "Portuguese" },
    { code: "ru", name: "Russian" },
    { code: "zh", name: "Chinese" },
    { code: "ja", name: "Japanese" },
  ];

  const csvTemplate = `email,firstName,lastName,department,role,language
john.doe@company.com,John,Doe,IT,user,en
jane.smith@company.com,Jane,Smith,HR,user,en
admin@company.com,Admin,User,IT,client_admin,en`;

  const csvImportMutation = useMutation({
    mutationFn: async (users: any[]) => {
      const results = [];
      for (const userData of users) {
        const response = await apiClient.createUser({
          ...userData,
          clientId: user?.clientId,
          language: userData.language || defaultLanguage,
          password: generateRandomPassword(),
        });
        results.push(response);
      }
      return results;
    },
    onSuccess: (results) => {
      const successful = results.filter(r => r.success).length;
      const failed = results.length - successful;
      
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Import Complete",
        description: `Successfully imported ${successful} users${failed > 0 ? `, ${failed} failed` : ''}`,
      });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import users",
        variant: "destructive",
      });
    },
  });

  const generateRandomPassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
    let password = '';
    for (let i = 0; i < 12; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
  };

  const resetForm = () => {
    setImportMethod(null);
    setDefaultLanguage("en");
    setCsvFile(null);
    setCsvData([]);
    setImportPreview(false);
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && file.type === 'text/csv') {
      setCsvFile(file);
      parseCSVFile(file);
    } else {
      toast({
        title: "Invalid File",
        description: "Please select a valid CSV file",
        variant: "destructive",
      });
    }
  };

  const parseCSVFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n');
      const headers = lines[0].split(',').map(h => h.trim());
      
      const data = lines.slice(1)
        .filter(line => line.trim())
        .map(line => {
          const values = line.split(',').map(v => v.trim());
          const row: any = {};
          headers.forEach((header, index) => {
            row[header] = values[index] || '';
          });
          return row;
        })
        .filter(row => row.email && row.firstName && row.lastName);

      setCsvData(data);
      setImportPreview(true);
    };
    
    reader.onerror = () => {
      toast({
        title: "File Error",
        description: "Failed to read the CSV file",
        variant: "destructive",
      });
    };
    
    reader.readAsText(file);
  };

  const handleDownloadTemplate = () => {
    const blob = new Blob([csvTemplate], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'user_import_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const handleAzureADConnect = () => {
    toast({
      title: "Azure AD Integration",
      description: "Azure AD integration would be configured here with proper OAuth flow",
      variant: "default",
    });
    // In a real implementation, this would initiate Azure AD OAuth flow
  };

  const handleImport = () => {
    if (importMethod === "csv" && csvData.length > 0) {
      csvImportMutation.mutate(csvData);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl" data-testid="user-import-modal">
        <DialogHeader className="border-b border-border pb-4">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>Import Users</DialogTitle>
              <p className="text-sm text-muted-foreground">
                Add users via CSV upload or Azure AD integration
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="close-modal"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>

        <div className="p-6 space-y-6">
          {!importMethod && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* CSV Upload */}
              <Card 
                className="cursor-pointer hover:bg-muted/20 transition-colors"
                onClick={() => setImportMethod("csv")}
                data-testid="csv-import-option"
              >
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <FileText className="text-primary w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    CSV Upload
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Upload a CSV file with user information
                  </p>
                  <Button className="w-full">
                    Choose CSV File
                  </Button>
                </CardContent>
              </Card>

              {/* Azure AD Integration */}
              <Card 
                className="cursor-pointer hover:bg-muted/20 transition-colors"
                onClick={() => setImportMethod("azure")}
                data-testid="azure-import-option"
              >
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <svg className="w-6 h-6 text-accent" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M1 12.5L5.5 8v9L1 12.5z"/>
                      <path d="M5.5 8L12 1.5V8h-6.5z"/>
                      <path d="M12 8h10.5L23 12.5 22.5 17H12V8z"/>
                      <path d="M12 17v5.5L5.5 17H12z"/>
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Azure AD Sync
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Sync users from your Azure Active Directory
                  </p>
                  <Button className="w-full bg-accent text-accent-foreground hover:opacity-90">
                    Connect Azure AD
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {importMethod === "csv" && !importPreview && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-primary/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Upload className="text-primary w-8 h-8" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Upload CSV File</h3>
                <p className="text-muted-foreground mb-4">
                  Select a CSV file containing user information
                </p>
                
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv"
                  onChange={handleFileChange}
                  className="hidden"
                  data-testid="file-input"
                />
                
                <Button onClick={handleFileSelect} data-testid="select-file">
                  <Upload className="w-4 h-4 mr-2" />
                  Choose File
                </Button>
                
                {csvFile && (
                  <p className="text-sm text-muted-foreground mt-2">
                    Selected: {csvFile.name}
                  </p>
                )}
              </div>

              {/* CSV Template */}
              <Card className="bg-muted/50">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-semibold text-foreground">
                      CSV Template Format
                    </h4>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleDownloadTemplate}
                      data-testid="download-template"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Template
                    </Button>
                  </div>
                  <div className="bg-card p-3 rounded border text-xs font-mono overflow-x-auto">
                    <pre className="text-muted-foreground whitespace-pre-wrap">
                      {csvTemplate}
                    </pre>
                  </div>
                </CardContent>
              </Card>

              <div>
                <Label htmlFor="default-language">Default Language for New Users</Label>
                <Select value={defaultLanguage} onValueChange={setDefaultLanguage}>
                  <SelectTrigger className="mt-2" data-testid="language-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {importMethod === "csv" && importPreview && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Import Preview</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setImportPreview(false)}
                  data-testid="back-to-upload"
                >
                  Back
                </Button>
              </div>

              <Card>
                <CardContent className="p-0">
                  <div className="max-h-64 overflow-y-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-muted/50 sticky top-0">
                        <tr>
                          <th className="text-left p-2">Email</th>
                          <th className="text-left p-2">Name</th>
                          <th className="text-left p-2">Department</th>
                          <th className="text-left p-2">Role</th>
                        </tr>
                      </thead>
                      <tbody>
                        {csvData.map((row, index) => (
                          <tr key={index} className="border-t border-border">
                            <td className="p-2">{row.email}</td>
                            <td className="p-2">{row.firstName} {row.lastName}</td>
                            <td className="p-2">{row.department}</td>
                            <td className="p-2">{row.role || 'user'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              <div className="text-sm text-muted-foreground">
                Found {csvData.length} valid users to import
              </div>
            </div>
          )}

          {importMethod === "azure" && (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-accent/20 rounded-lg flex items-center justify-center mx-auto">
                <svg className="w-8 h-8 text-accent" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M1 12.5L5.5 8v9L1 12.5z"/>
                  <path d="M5.5 8L12 1.5V8h-6.5z"/>
                  <path d="M12 8h10.5L23 12.5 22.5 17H12V8z"/>
                  <path d="M12 17v5.5L5.5 17H12z"/>
                </svg>
              </div>
              <h3 className="text-lg font-semibold">Azure AD Integration</h3>
              <p className="text-muted-foreground">
                Connect to your Azure Active Directory to sync user accounts
              </p>
              <Button
                onClick={handleAzureADConnect}
                className="bg-accent text-accent-foreground hover:opacity-90"
                data-testid="connect-azure"
              >
                Connect to Azure AD
              </Button>
            </div>
          )}

          {/* Footer */}
          <div className="flex justify-end space-x-3 pt-6 border-t border-border">
            <Button 
              variant="ghost" 
              onClick={onClose}
              data-testid="cancel-import"
            >
              Cancel
            </Button>
            
            {importMethod === "csv" && importPreview && (
              <Button
                onClick={handleImport}
                disabled={csvImportMutation.isPending || csvData.length === 0}
                data-testid="confirm-import"
              >
                {csvImportMutation.isPending ? "Importing..." : `Import ${csvData.length} Users`}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
