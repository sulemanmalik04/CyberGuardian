import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { X, Eye, Send } from "lucide-react";
import { apiClient } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface CampaignModalProps {
  isOpen: boolean;
  onClose: () => void;
  campaign?: any;
}

export function CampaignModal({ isOpen, onClose, campaign }: CampaignModalProps) {
  const [formData, setFormData] = useState({
    name: campaign?.name || "",
    template: {
      subject: campaign?.template?.subject || "",
      content: campaign?.template?.content || "",
      domain: campaign?.template?.domain || "",
    },
    targets: {
      userIds: campaign?.targets?.userIds || [],
      groups: campaign?.targets?.groups || [],
      totalCount: 0,
    },
    scheduledAt: campaign?.scheduledAt ? new Date(campaign.scheduledAt).toISOString().slice(0, 16) : "",
    settings: {
      trackOpens: campaign?.settings?.trackOpens ?? true,
      trackClicks: campaign?.settings?.trackClicks ?? true,
      enableReporting: campaign?.settings?.enableReporting ?? false,
    },
  });
  
  const [selectedTemplate, setSelectedTemplate] = useState(campaign?.template?.type || "");
  const [scheduleType, setScheduleType] = useState("immediate");
  const [previewMode, setPreviewMode] = useState(false);
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: users } = useQuery({
    queryKey: ['/api/users', user?.clientId],
    queryFn: async () => {
      const response = await apiClient.getUsers(user?.clientId);
      return response.data || [];
    },
    enabled: isOpen,
  });

  const { data: phishingTemplates } = useQuery({
    queryKey: ['/api/ai/phishing-templates'],
    queryFn: async () => {
      // Pre-defined templates for different scenarios
      return [
        { id: "fake-bank", name: "Fake Banking Alert", type: "financial" },
        { id: "fake-it", name: "IT Support Request", type: "technical" },
        { id: "fake-hr", name: "HR Policy Update", type: "corporate" },
        { id: "fake-delivery", name: "Package Delivery", type: "logistics" },
        { id: "fake-security", name: "Security Alert", type: "security" },
      ];
    },
  });

  const generateContentMutation = useMutation({
    mutationFn: async (templateType: string) => {
      const response = await apiClient.generatePhishingContent(templateType, "general");
      return response.data;
    },
    onSuccess: (data) => {
      setFormData(prev => ({
        ...prev,
        template: {
          ...prev.template,
          subject: data.subject,
          content: data.content,
        }
      }));
    },
  });

  const createCampaignMutation = useMutation({
    mutationFn: async (campaignData: any) => {
      const response = await apiClient.createCampaign(campaignData);
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
      toast({
        title: "Success",
        description: "Campaign created successfully",
      });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create campaign",
        variant: "destructive",
      });
    },
  });

  const launchCampaignMutation = useMutation({
    mutationFn: async (campaignId: string) => {
      const response = await apiClient.launchCampaign(campaignId);
      return response.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
      toast({
        title: "Campaign Launched",
        description: `Campaign sent to ${data.sent} users successfully`,
      });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Launch Failed",
        description: error.message || "Failed to launch campaign",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      template: { subject: "", content: "", domain: "" },
      targets: { userIds: [], groups: [], totalCount: 0 },
      scheduledAt: "",
      settings: { trackOpens: true, trackClicks: true, enableReporting: false },
    });
    setSelectedTemplate("");
    setScheduleType("immediate");
    setPreviewMode(false);
  };

  const handleTemplateSelect = async (templateId: string) => {
    setSelectedTemplate(templateId);
    if (templateId && templateId !== "custom") {
      generateContentMutation.mutate(templateId);
    }
  };

  const handleTargetGroupChange = (group: string, checked: boolean) => {
    const groupUsers = users?.filter((user: any) => user.department === group) || [];
    
    setFormData(prev => ({
      ...prev,
      targets: {
        ...prev.targets,
        groups: checked 
          ? [...prev.targets.groups, group]
          : prev.targets.groups.filter(g => g !== group),
        userIds: checked
          ? [...prev.targets.userIds, ...groupUsers.map((u: any) => u._id)]
          : prev.targets.userIds.filter(id => !groupUsers.some((u: any) => u._id === id)),
        totalCount: checked
          ? prev.targets.totalCount + groupUsers.length
          : prev.targets.totalCount - groupUsers.length,
      }
    }));
  };

  const handleSubmit = async (launch: boolean = false) => {
    if (!formData.name || !formData.template.subject || !formData.template.content) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const campaignData = {
      ...formData,
      clientId: user?.clientId,
      scheduledAt: scheduleType === "scheduled" && formData.scheduledAt ? new Date(formData.scheduledAt) : undefined,
      status: launch ? "sending" : "draft",
    };

    if (launch) {
      // Create and immediately launch
      const createResult = await createCampaignMutation.mutateAsync(campaignData);
      if (createResult) {
        launchCampaignMutation.mutate(createResult._id);
      }
    } else {
      createCampaignMutation.mutate(campaignData);
    }
  };

  const uniqueGroups = [...new Set(users?.map((user: any) => user.department).filter(Boolean))] || [];

  const domains = [
    "securebank-login.com",
    "microsoftupdate.net", 
    "paypal-verify.org",
    "amazon-security.co",
    "office365-alert.net",
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] flex flex-col" data-testid="campaign-modal">
        <DialogHeader className="border-b border-border pb-4">
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>
                {campaign ? "Edit Campaign" : "Create Phishing Campaign"}
              </DialogTitle>
              <p className="text-sm text-muted-foreground">
                Design and launch a new phishing simulation
              </p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="close-modal"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto p-6">
          {!previewMode ? (
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left Column */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="campaign-name">Campaign Name</Label>
                    <Input
                      id="campaign-name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Q1 Security Awareness Test"
                      data-testid="campaign-name"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="email-template">Email Template</Label>
                    <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
                      <SelectTrigger data-testid="template-select">
                        <SelectValue placeholder="Select a template" />
                      </SelectTrigger>
                      <SelectContent>
                        {phishingTemplates?.map((template) => (
                          <SelectItem key={template.id} value={template.id}>
                            {template.name}
                          </SelectItem>
                        ))}
                        <SelectItem value="custom">Custom Template</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Target Groups</Label>
                    <div className="space-y-2 mt-2">
                      <label className="flex items-center">
                        <Checkbox
                          checked={formData.targets.userIds.length === users?.length}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFormData(prev => ({
                                ...prev,
                                targets: {
                                  userIds: users?.map((u: any) => u._id) || [],
                                  groups: ["all-users"],
                                  totalCount: users?.length || 0,
                                }
                              }));
                            } else {
                              setFormData(prev => ({
                                ...prev,
                                targets: { userIds: [], groups: [], totalCount: 0 }
                              }));
                            }
                          }}
                          data-testid="target-all-users"
                        />
                        <span className="ml-3 text-sm">All Users ({users?.length || 0})</span>
                      </label>

                      {uniqueGroups.map((group) => {
                        const groupUserCount = users?.filter((u: any) => u.department === group).length || 0;
                        return (
                          <label key={group} className="flex items-center">
                            <Checkbox
                              checked={formData.targets.groups.includes(group)}
                              onCheckedChange={(checked) => handleTargetGroupChange(group, checked as boolean)}
                              data-testid={`target-group-${group}`}
                            />
                            <span className="ml-3 text-sm">{group} ({groupUserCount})</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Right Column */}
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="phishing-domain">Phishing Domain</Label>
                    <Select 
                      value={formData.template.domain} 
                      onValueChange={(value) => setFormData(prev => ({
                        ...prev,
                        template: { ...prev.template, domain: value }
                      }))}
                    >
                      <SelectTrigger data-testid="domain-select">
                        <SelectValue placeholder="Select domain" />
                      </SelectTrigger>
                      <SelectContent>
                        {domains.map((domain) => (
                          <SelectItem key={domain} value={domain}>
                            {domain}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Schedule</Label>
                    <div className="space-y-2 mt-2">
                      <label className="flex items-center">
                        <input 
                          type="radio" 
                          name="schedule" 
                          value="immediate" 
                          checked={scheduleType === "immediate"}
                          onChange={(e) => setScheduleType(e.target.value)}
                          className="mr-3"
                          data-testid="schedule-immediate"
                        />
                        <span className="text-sm">Send immediately</span>
                      </label>
                      <label className="flex items-center">
                        <input 
                          type="radio" 
                          name="schedule" 
                          value="scheduled" 
                          checked={scheduleType === "scheduled"}
                          onChange={(e) => setScheduleType(e.target.value)}
                          className="mr-3"
                          data-testid="schedule-later"
                        />
                        <span className="text-sm">Schedule for later</span>
                      </label>
                    </div>
                    {scheduleType === "scheduled" && (
                      <Input
                        type="datetime-local"
                        value={formData.scheduledAt}
                        onChange={(e) => setFormData(prev => ({ ...prev, scheduledAt: e.target.value }))}
                        className="mt-2"
                        data-testid="scheduled-time"
                      />
                    )}
                  </div>

                  <div>
                    <Label>Advanced Options</Label>
                    <div className="space-y-2 mt-2">
                      <label className="flex items-center">
                        <Checkbox
                          checked={formData.settings.trackOpens}
                          onCheckedChange={(checked) => setFormData(prev => ({
                            ...prev,
                            settings: { ...prev.settings, trackOpens: checked as boolean }
                          }))}
                          data-testid="track-opens"
                        />
                        <span className="ml-3 text-sm">Track email opens</span>
                      </label>
                      <label className="flex items-center">
                        <Checkbox
                          checked={formData.settings.trackClicks}
                          onCheckedChange={(checked) => setFormData(prev => ({
                            ...prev,
                            settings: { ...prev.settings, trackClicks: checked as boolean }
                          }))}
                          data-testid="track-clicks"
                        />
                        <span className="ml-3 text-sm">Track link clicks</span>
                      </label>
                      <label className="flex items-center">
                        <Checkbox
                          checked={formData.settings.enableReporting}
                          onCheckedChange={(checked) => setFormData(prev => ({
                            ...prev,
                            settings: { ...prev.settings, enableReporting: checked as boolean }
                          }))}
                          data-testid="enable-reporting"
                        />
                        <span className="ml-3 text-sm">Allow "Report as Phishing" button</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              {/* Email Content */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="email-subject">Email Subject</Label>
                  <Input
                    id="email-subject"
                    value={formData.template.subject}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      template: { ...prev.template, subject: e.target.value }
                    }))}
                    placeholder="Urgent: Verify Your Account"
                    data-testid="email-subject"
                  />
                </div>

                <div>
                  <Label htmlFor="email-content">Email Content</Label>
                  <Textarea
                    id="email-content"
                    value={formData.template.content}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      template: { ...prev.template, content: e.target.value }
                    }))}
                    placeholder="Enter your email content here..."
                    className="min-h-[200px]"
                    data-testid="email-content"
                  />
                </div>
              </div>
            </form>
          ) : (
            /* Email Preview */
            <Card>
              <CardContent className="p-0">
                <div className="bg-white text-black p-6 rounded border max-h-96 overflow-y-auto">
                  <div className="text-sm text-gray-600 mb-4">
                    From: noreply@{formData.template.domain}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">
                    {formData.template.subject}
                  </h3>
                  <div 
                    className="text-gray-700 whitespace-pre-wrap"
                    dangerouslySetInnerHTML={{ __html: formData.template.content }}
                  />
                  <p className="text-gray-600 text-xs mt-4 border-t pt-4">
                    This is a simulated phishing email for training purposes.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center pt-6 border-t border-border">
          <div className="text-sm text-muted-foreground">
            {formData.targets.totalCount > 0 && (
              <span>Targeting {formData.targets.totalCount} users</span>
            )}
          </div>
          
          <div className="flex space-x-3">
            <Button 
              type="button" 
              variant="ghost" 
              onClick={onClose}
              data-testid="cancel-campaign"
            >
              Cancel
            </Button>
            
            <Button 
              type="button" 
              variant="secondary"
              onClick={() => setPreviewMode(!previewMode)}
              data-testid="preview-campaign"
            >
              <Eye className="w-4 h-4 mr-2" />
              {previewMode ? "Edit" : "Preview"}
            </Button>
            
            <Button
              type="button"
              variant="outline"
              onClick={() => handleSubmit(false)}
              disabled={createCampaignMutation.isPending}
              data-testid="save-draft"
            >
              Save Draft
            </Button>
            
            <Button
              type="button"
              onClick={() => handleSubmit(true)}
              disabled={createCampaignMutation.isPending || launchCampaignMutation.isPending}
              className="font-medium"
              data-testid="launch-campaign"
            >
              <Send className="w-4 h-4 mr-2" />
              Launch Campaign
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
