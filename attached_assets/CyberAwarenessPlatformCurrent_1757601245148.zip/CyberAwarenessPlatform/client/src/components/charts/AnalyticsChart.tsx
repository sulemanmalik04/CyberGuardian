import { useMemo } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { chartColors, defaultChartConfig } from '@/lib/chartConfig';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface AnalyticsChartProps {
  type: 'line' | 'bar' | 'pie';
  title: string;
  data: any[];
  xKey: string;
  yKey: string;
  height?: number;
  className?: string;
}

export function AnalyticsChart({ 
  type, 
  title, 
  data, 
  xKey, 
  yKey, 
  height = 300,
  className 
}: AnalyticsChartProps) {
  
  const chartData = useMemo(() => {
    if (type === 'pie') {
      return {
        labels: data.map(item => item[xKey]),
        datasets: [
          {
            data: data.map(item => item[yKey]),
            backgroundColor: [
              chartColors.primary,
              chartColors.accent,
              chartColors.secondary,
              chartColors.destructive,
              chartColors.warning,
              chartColors.info,
            ],
            borderColor: 'hsl(0, 0%, 100%)',
            borderWidth: 2,
          },
        ],
      };
    }

    return {
      labels: data.map(item => item[xKey]),
      datasets: [
        {
          label: title,
          data: data.map(item => item[yKey]),
          backgroundColor: type === 'line' ? 'transparent' : chartColors.primary,
          borderColor: chartColors.primary,
          borderWidth: 2,
          fill: type === 'line',
          tension: type === 'line' ? 0.4 : 0,
          pointBackgroundColor: chartColors.primary,
          pointBorderColor: 'hsl(0, 0%, 100%)',
          pointBorderWidth: 2,
          pointRadius: type === 'line' ? 4 : 0,
        },
      ],
    };
  }, [data, xKey, yKey, title, type]);

  const options = useMemo(() => {
    if (type === 'pie') {
      return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right' as const,
            labels: {
              usePointStyle: true,
              padding: 20,
            },
          },
          tooltip: {
            backgroundColor: 'hsl(0, 0%, 100%)',
            titleColor: 'hsl(222.2, 84%, 4.9%)',
            bodyColor: 'hsl(222.2, 84%, 4.9%)',
            borderColor: 'hsl(214.3, 31.8%, 91.4%)',
            borderWidth: 1,
            cornerRadius: 8,
            padding: 12,
          },
        },
      };
    }

    return defaultChartConfig;
  }, [type]);

  const ChartComponent = type === 'line' ? Line : type === 'bar' ? Bar : Pie;

  return (
    <Card className={className} data-testid={`${type}-chart`}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div style={{ height: `${height}px` }}>
          <ChartComponent data={chartData} options={options} />
        </div>
      </CardContent>
    </Card>
  );
}
