import { eq, and, desc, asc, gte, lte, sql } from 'drizzle-orm';
import { db } from './db';
import {
  users, clients, courses, phishingCampaigns, analyticsEvents, sessions,
  type User, type InsertUser,
  type Client, type InsertClient,
  type Course, type InsertCourse,
  type PhishingCampaign, type InsertPhishingCampaign,
  type AnalyticsEvent, type InsertAnalyticsEvent,
  type Session, type InsertSession
} from '@shared/schema';
import { hashPassword, comparePassword } from './services/auth';

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | null>;
  getUserByEmail(email: string): Promise<User | null>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | null>;
  deleteUser(id: number): Promise<boolean>;
  getUsersByClientId(clientId: number): Promise<User[]>;
  authenticateUser(email: string, password: string): Promise<User | null>;
  
  // Client operations
  getClient(id: number): Promise<Client | null>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, updates: Partial<Client>): Promise<Client | null>;
  deleteClient(id: number): Promise<boolean>;
  getAllClients(): Promise<Client[]>;
  
  // Course operations
  getCourse(id: number): Promise<Course | null>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, updates: Partial<Course>): Promise<Course | null>;
  deleteCourse(id: number): Promise<boolean>;
  getAllCourses(): Promise<Course[]>;
  getCoursesByLanguage(language: string): Promise<Course[]>;
  
  // Campaign operations
  getCampaign(id: number): Promise<PhishingCampaign | null>;
  createCampaign(campaign: InsertPhishingCampaign): Promise<PhishingCampaign>;
  updateCampaign(id: number, updates: Partial<PhishingCampaign>): Promise<PhishingCampaign | null>;
  deleteCampaign(id: number): Promise<boolean>;
  getCampaignsByClientId(clientId: number): Promise<PhishingCampaign[]>;
  
  // Analytics operations
  createAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent>;
  getAnalyticsEvents(filters: {
    clientId?: string;
    campaignId?: string;
    eventType?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<AnalyticsEvent[]>;
  
  // Session operations
  createSession(session: InsertSession): Promise<Session>;
  getSession(id: string): Promise<Session | null>;
  updateSession(id: string, updates: Partial<Session>): Promise<Session | null>;
  deleteSession(id: string): Promise<boolean>;
  getActiveSessionsByUserId(userId: number): Promise<Session[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | null> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return (result[0] as User) || null;
  }

  async getUserByEmail(email: string): Promise<User | null> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return (result[0] as User) || null;
  }

  async createUser(user: InsertUser): Promise<User> {
    // Hash password before storing
    const hashedPassword = await hashPassword(user.password);
    const userWithHashedPassword = { 
      ...user, 
      password: hashedPassword,
      progress: user.progress as any // Type assertion for JSON field
    };
    
    const result = await db.insert(users).values([userWithHashedPassword]).returning();
    return result[0] as User;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | null> {
    // Hash password if being updated
    if (updates.password) {
      updates.password = await hashPassword(updates.password);
    }
    
    const updateData = {
      ...updates,
      updatedAt: new Date(),
      progress: updates.progress as any // Type assertion for JSON field
    };
    
    const result = await db.update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    
    return (result[0] as User) || null;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getUsersByClientId(clientId: number): Promise<User[]> {
    const result = await db.select().from(users).where(eq(users.clientId, clientId));
    return result as User[];
  }

  // Client operations
  async getClient(id: number): Promise<Client | null> {
    const result = await db.select().from(clients).where(eq(clients.id, id)).limit(1);
    return (result[0] as Client) || null;
  }

  async createClient(client: InsertClient): Promise<Client> {
    const clientData = {
      ...client,
      branding: client.branding as any, // Type assertion for JSON field
      settings: client.settings as any // Type assertion for JSON field
    };
    const result = await db.insert(clients).values([clientData]).returning();
    return result[0] as Client;
  }

  async updateClient(id: number, updates: Partial<Client>): Promise<Client | null> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
      branding: updates.branding as any, // Type assertion for JSON field
      settings: updates.settings as any // Type assertion for JSON field
    };
    
    const result = await db.update(clients)
      .set(updateData)
      .where(eq(clients.id, id))
      .returning();
    
    return (result[0] as Client) || null;
  }

  async deleteClient(id: number): Promise<boolean> {
    const result = await db.delete(clients).where(eq(clients.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getAllClients(): Promise<Client[]> {
    const result = await db.select().from(clients).orderBy(asc(clients.name));
    return result as Client[];
  }

  // Course operations
  async getCourse(id: number): Promise<Course | null> {
    const result = await db.select().from(courses).where(eq(courses.id, id)).limit(1);
    return (result[0] as Course) || null;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const courseData = {
      ...course,
      content: course.content as any, // Type assertion for JSON field
      tags: course.tags as any // Type assertion for JSON field
    };
    const result = await db.insert(courses).values([courseData]).returning();
    return result[0] as Course;
  }

  async updateCourse(id: number, updates: Partial<Course>): Promise<Course | null> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
      content: updates.content as any, // Type assertion for JSON field
      tags: updates.tags as any // Type assertion for JSON field
    };
    
    const result = await db.update(courses)
      .set(updateData)
      .where(eq(courses.id, id))
      .returning();
    
    return (result[0] as Course) || null;
  }

  async deleteCourse(id: number): Promise<boolean> {
    const result = await db.delete(courses).where(eq(courses.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getAllCourses(): Promise<Course[]> {
    const result = await db.select().from(courses).where(eq(courses.isPublished, true)).orderBy(asc(courses.title));
    return result as Course[];
  }

  async getCoursesByLanguage(language: string): Promise<Course[]> {
    const result = await db.select().from(courses)
      .where(and(eq(courses.language, language), eq(courses.isPublished, true)))
      .orderBy(asc(courses.title));
    return result as Course[];
  }

  // Campaign operations
  async getCampaign(id: number): Promise<PhishingCampaign | null> {
    const result = await db.select().from(phishingCampaigns).where(eq(phishingCampaigns.id, id)).limit(1);
    return (result[0] as PhishingCampaign) || null;
  }

  async createCampaign(campaign: InsertPhishingCampaign): Promise<PhishingCampaign> {
    const campaignData = {
      ...campaign,
      template: campaign.template as any, // Type assertion for JSON field
      targetUsers: campaign.targetUsers as any, // Type assertion for JSON field
      schedule: campaign.schedule as any, // Type assertion for JSON field
      tracking: campaign.tracking as any, // Type assertion for JSON field
      domains: campaign.domains as any // Type assertion for JSON field
    };
    const result = await db.insert(phishingCampaigns).values([campaignData]).returning();
    return result[0] as PhishingCampaign;
  }

  async updateCampaign(id: number, updates: Partial<PhishingCampaign>): Promise<PhishingCampaign | null> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
      template: updates.template as any, // Type assertion for JSON field
      targetUsers: updates.targetUsers as any, // Type assertion for JSON field
      schedule: updates.schedule as any, // Type assertion for JSON field
      tracking: updates.tracking as any, // Type assertion for JSON field
      domains: updates.domains as any // Type assertion for JSON field
    };
    
    const result = await db.update(phishingCampaigns)
      .set(updateData)
      .where(eq(phishingCampaigns.id, id))
      .returning();
    
    return (result[0] as PhishingCampaign) || null;
  }

  async deleteCampaign(id: number): Promise<boolean> {
    const result = await db.delete(phishingCampaigns).where(eq(phishingCampaigns.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getCampaignsByClientId(clientId: number): Promise<PhishingCampaign[]> {
    const result = await db.select().from(phishingCampaigns)
      .where(eq(phishingCampaigns.clientId, clientId))
      .orderBy(desc(phishingCampaigns.createdAt));
    return result as PhishingCampaign[];
  }

  // Analytics operations
  async createAnalyticsEvent(event: InsertAnalyticsEvent): Promise<AnalyticsEvent> {
    const eventData = {
      ...event,
      metadata: event.metadata as any // Type assertion for JSON field
    };
    const result = await db.insert(analyticsEvents).values([eventData]).returning();
    return result[0] as AnalyticsEvent;
  }

  async getAnalyticsEvents(filters: {
    clientId?: string;
    campaignId?: string;
    eventType?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<AnalyticsEvent[]> {
    const conditions = [];
    
    if (filters.clientId) {
      conditions.push(eq(analyticsEvents.clientId, filters.clientId));
    }
    
    if (filters.campaignId) {
      conditions.push(eq(analyticsEvents.campaignId, filters.campaignId));
    }
    
    if (filters.eventType) {
      conditions.push(eq(analyticsEvents.eventType, filters.eventType));
    }
    
    if (filters.startDate) {
      conditions.push(gte(analyticsEvents.timestamp, filters.startDate));
    }
    
    if (filters.endDate) {
      conditions.push(lte(analyticsEvents.timestamp, filters.endDate));
    }
    
    if (conditions.length > 0) {
      const result = await db.select().from(analyticsEvents)
        .where(and(...conditions))
        .orderBy(desc(analyticsEvents.timestamp));
      return result as AnalyticsEvent[];
    } else {
      const result = await db.select().from(analyticsEvents)
        .orderBy(desc(analyticsEvents.timestamp));
      return result as AnalyticsEvent[];
    }
  }

  // Session operations
  async createSession(session: InsertSession): Promise<Session> {
    const result = await db.insert(sessions).values([session]).returning();
    return result[0] as Session;
  }

  async getSession(id: string): Promise<Session | null> {
    const result = await db.select().from(sessions)
      .where(and(eq(sessions.id, id), eq(sessions.isActive, true)))
      .limit(1);
    return (result[0] as Session) || null;
  }

  async updateSession(id: string, updates: Partial<Session>): Promise<Session | null> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
    };
    
    const result = await db.update(sessions)
      .set(updateData)
      .where(eq(sessions.id, id))
      .returning();
    
    return (result[0] as Session) || null;
  }

  async deleteSession(id: string): Promise<boolean> {
    const result = await db.delete(sessions).where(eq(sessions.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getActiveSessionsByUserId(userId: number): Promise<Session[]> {
    const result = await db.select().from(sessions)
      .where(and(eq(sessions.userId, userId), eq(sessions.isActive, true)))
      .orderBy(desc(sessions.createdAt));
    return result as Session[];
  }

  async authenticateUser(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (!user) {
      return null;
    }

    const isValid = await comparePassword(password, user.password);
    if (!isValid) {
      return null;
    }

    return user;
  }
}

export const storage = new DatabaseStorage();