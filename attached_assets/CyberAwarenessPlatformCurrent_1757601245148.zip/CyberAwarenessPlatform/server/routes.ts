import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authenticateToken, requireRole, requireClientAccess, AuthenticatedRequest } from "./middleware/auth";
import { generateToken } from "./services/auth";
import { generateAIResponse, generateQuizQuestions, generateTrainingRecommendations, generatePhishingContent } from "./services/openai";
import { sendBulkPhishingEmails, trackEmailOpen, trackEmailClick } from "./services/sendgrid";
import { loginSchema, registerSchema, insertUserSchema, insertClientSchema, insertCourseSchema, insertPhishingCampaignSchema } from "@shared/schema";
import { Request, Response } from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Authentication routes
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.authenticateUser(email, password);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = generateToken(user);
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      res.json({ 
        user: userWithoutPassword, 
        token,
        message: "Login successful" 
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(409).json({ message: "User already exists" });
      }

      const newUser = await storage.createUser({
        ...userData,
        role: 'user',
        status: 'active',
        language: 'en',
      });

      const token = generateToken(newUser);
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = newUser;
      
      res.status(201).json({ 
        user: userWithoutPassword, 
        token,
        message: "Registration successful" 
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const user = await storage.getUser(parseInt(req.user!.userId.toString()));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Get user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User management routes
  app.get("/api/users", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      let users;
      
      if (req.user!.role === 'super_admin') {
        const clientId = req.query.clientId as string;
        if (clientId) {
          users = await storage.getUsersByClientId(parseInt(clientId));
        } else {
          // For super admin, we need to implement a method to get all users
          users = await storage.getUsersByClientId(0); // This will need to be modified in storage
        }
      } else {
        users = await storage.getUsersByClientId(parseInt(req.user!.clientId!.toString()));
      }

      // Remove passwords from response
      const usersWithoutPasswords = users.map(({ password, ...user }) => user);
      res.json(usersWithoutPasswords);
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/users", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Set clientId for client admins
      if (req.user!.role === 'client_admin') {
        userData.clientId = parseInt(req.user!.clientId!.toString());
      }

      const newUser = await storage.createUser(userData);
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Create user error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.put("/api/users/:id", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedUser = await storage.updateUser(parseInt(id), updates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Remove password from response
      const { password: _, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Update user error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.delete("/api/users/:id", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      
      const deleted = await storage.deleteUser(parseInt(id));
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Client management routes (Super Admin only)
  app.get("/api/clients", authenticateToken, requireRole('super_admin'), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const clients = await storage.getAllClients();
      res.json(clients);
    } catch (error) {
      console.error("Get clients error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/clients", authenticateToken, requireRole('super_admin'), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const clientData = insertClientSchema.parse(req.body);
      const newClient = await storage.createClient(clientData);
      res.status(201).json(newClient);
    } catch (error) {
      console.error("Create client error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.put("/api/clients/:id", authenticateToken, requireRole('super_admin'), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedClient = await storage.updateClient(parseInt(id), updates);
      if (!updatedClient) {
        return res.status(404).json({ message: "Client not found" });
      }

      res.json(updatedClient);
    } catch (error) {
      console.error("Update client error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Course management routes
  app.get("/api/courses", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const language = req.query.language as string;
      
      let courses;
      if (language) {
        courses = await storage.getCoursesByLanguage(language);
      } else {
        courses = await storage.getAllCourses();
      }

      res.json(courses);
    } catch (error) {
      console.error("Get courses error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/courses", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const newCourse = await storage.createCourse(courseData);
      res.status(201).json(newCourse);
    } catch (error) {
      console.error("Create course error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.put("/api/courses/:id", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const updatedCourse = await storage.updateCourse(parseInt(id), updates);
      if (!updatedCourse) {
        return res.status(404).json({ message: "Course not found" });
      }

      res.json(updatedCourse);
    } catch (error) {
      console.error("Update course error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Phishing campaign routes
  app.get("/api/campaigns", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      let campaigns;
      
      if (req.user!.role === 'super_admin') {
        const clientId = req.query.clientId as string;
        if (clientId) {
          campaigns = await storage.getCampaignsByClientId(parseInt(clientId));
        } else {
          // For super admin, we might need to get all campaigns
          campaigns = await storage.getCampaignsByClientId(0); // This will need modification
        }
      } else {
        campaigns = await storage.getCampaignsByClientId(parseInt(req.user!.clientId!.toString()));
      }

      res.json(campaigns);
    } catch (error) {
      console.error("Get campaigns error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/campaigns", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const campaignData = insertPhishingCampaignSchema.parse(req.body);
      
      // Set clientId for client admins
      if (req.user!.role === 'client_admin') {
        campaignData.clientId = parseInt(req.user!.clientId!.toString());
      }

      const newCampaign = await storage.createCampaign(campaignData);
      res.status(201).json(newCampaign);
    } catch (error) {
      console.error("Create campaign error:", error);
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.post("/api/campaigns/:id/launch", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      
      const campaign = await storage.getCampaign(parseInt(id));
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Get target users
      const users = await storage.getUsersByClientId(campaign.clientId);
      const targetUsers = users
        .filter(user => user.id && (
          campaign.targetUsers.includes(user.id.toString()) || 
          (user.department && campaign.targetUsers.includes(user.department))
        ))
        .map(user => ({ id: user.id, email: user.email }));

      // Send emails using SendGrid
      const trackingDomain = process.env.FRONTEND_URL || 'http://localhost:5000';
      const result = await sendBulkPhishingEmails(campaign, targetUsers, trackingDomain);

      // Update campaign status
      await storage.updateCampaign(parseInt(id), {
        status: 'completed',
        tracking: {
          sent: result.success,
          opened: campaign.tracking?.opened || 0,
          clicked: campaign.tracking?.clicked || 0,
          reported: campaign.tracking?.reported || 0,
        }
      });

      res.json({ 
        message: "Campaign launched successfully",
        sent: result.success,
        failed: result.failed
      });
    } catch (error) {
      console.error("Launch campaign error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Email tracking routes
  app.get("/api/tracking/open/:campaignId/:userId", async (req: Request, res: Response) => {
    try {
      const { campaignId, userId } = req.params;
      
      await trackEmailOpen(parseInt(campaignId), parseInt(userId));
      
      // Return a 1x1 pixel image
      const pixel = Buffer.from('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7', 'base64');
      res.writeHead(200, {
        'Content-Type': 'image/gif',
        'Content-Length': pixel.length,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
      });
      res.end(pixel);
    } catch (error) {
      console.error("Email tracking error:", error);
      res.status(500).end();
    }
  });

  app.get("/api/tracking/click/:campaignId/:userId", async (req: Request, res: Response) => {
    try {
      const { campaignId, userId } = req.params;
      const url = req.query.url as string;
      
      await trackEmailClick(parseInt(campaignId), parseInt(userId), url);
      
      // Redirect to the actual URL or a warning page
      res.redirect(url || '/phishing-warning');
    } catch (error) {
      console.error("Click tracking error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // AI Assistant routes
  app.post("/api/ai/chat", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { messages, context } = req.body;
      
      const response = await generateAIResponse(
        messages,
        req.user!.role,
        context
      );

      res.json({ response });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ message: "Failed to generate AI response" });
    }
  });

  app.post("/api/ai/generate-quiz", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { courseContent, questionCount } = req.body;
      
      const questions = await generateQuizQuestions(courseContent, questionCount);
      
      res.json({ questions });
    } catch (error) {
      console.error("Generate quiz error:", error);
      res.status(500).json({ message: "Failed to generate quiz questions" });
    }
  });

  app.post("/api/ai/recommendations", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { userPerformance } = req.body;
      
      const courses = await storage.getAllCourses();
      const recommendations = await generateTrainingRecommendations(userPerformance, courses);
      
      res.json({ recommendations });
    } catch (error) {
      console.error("Generate recommendations error:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  app.post("/api/ai/generate-phishing", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { templateType, targetAudience } = req.body;
      
      const content = await generatePhishingContent(templateType, targetAudience);
      
      res.json(content);
    } catch (error) {
      console.error("Generate phishing content error:", error);
      res.status(500).json({ message: "Failed to generate phishing content" });
    }
  });

  // Analytics routes
  app.get("/api/analytics", authenticateToken, requireRole(['super_admin', 'client_admin']), async (req: AuthenticatedRequest, res: Response) => {
    try {
      const { startDate, endDate, eventType, campaignId } = req.query;
      
      const filters: any = {
        clientId: req.user!.role === 'client_admin' ? req.user!.clientId?.toString() : req.query.clientId as string,
      };

      if (startDate) filters.startDate = new Date(startDate as string);
      if (endDate) filters.endDate = new Date(endDate as string);
      if (eventType) filters.eventType = eventType as string;
      if (campaignId) filters.campaignId = campaignId as string;

      const events = await storage.getAnalyticsEvents(filters);
      
      res.json(events);
    } catch (error) {
      console.error("Get analytics error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Dashboard stats route
  app.get("/api/dashboard/stats", authenticateToken, async (req: AuthenticatedRequest, res: Response) => {
    try {
      const clientIdParam = req.user!.role === 'client_admin' ? req.user!.clientId : req.query.clientId as string;
      
      if (!clientIdParam) {
        return res.status(400).json({ message: "Client ID required" });
      }

      const clientId = typeof clientIdParam === 'string' ? parseInt(clientIdParam) : clientIdParam;

      // Get basic stats
      const users = await storage.getUsersByClientId(clientId);
      const campaigns = await storage.getCampaignsByClientId(clientId);
      const courses = await storage.getAllCourses();

      // Calculate training completion rate
      const totalUsers = users.length;
      const usersWithProgress = users.filter(user => user.progress && typeof user.progress === 'object' && user.progress !== null && 'coursesCompleted' in user.progress && (user.progress as any).coursesCompleted > 0);
      const completionRate = totalUsers > 0 ? (usersWithProgress.length / totalUsers) * 100 : 0;

      // Get recent analytics
      const recentEvents = await storage.getAnalyticsEvents({
        clientId: clientId.toString(),
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
      });

      const stats = {
        activeUsers: users.filter(user => user.status === 'active').length,
        campaignsSent: campaigns.filter(campaign => campaign.status === 'completed').length,
        completionRate: Math.round(completionRate * 10) / 10,
        securityScore: Math.min(100, Math.max(0, 100 - (recentEvents.filter(e => e.eventType === 'link_clicked').length * 2))),
        totalCourses: courses.length,
        recentActivity: recentEvents.length,
      };

      res.json(stats);
    } catch (error) {
      console.error("Get dashboard stats error:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
