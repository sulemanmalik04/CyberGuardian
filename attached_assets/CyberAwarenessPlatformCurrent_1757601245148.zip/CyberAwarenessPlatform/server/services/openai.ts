import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export async function generateAIResponse(
  messages: ChatMessage[],
  userRole: string,
  userContext?: any
): Promise<string> {
  try {
    const systemPrompt = `You are a cybersecurity training AI assistant. You help ${userRole}s with cybersecurity awareness and training.
    
    ${userRole === 'client_admin' ? `
    You can help with:
    - Creating phishing campaigns
    - Generating quiz questions
    - Analyzing training effectiveness
    - Recommending training modules
    - User management advice
    ` : userRole === 'user' ? `
    You can help with:
    - Learning cybersecurity best practices
    - Understanding phishing techniques
    - Password security recommendations
    - Incident reporting guidance
    ` : `
    You can help with:
    - Platform management
    - Client configuration
    - System-wide analytics
    - License management
    `}
    
    Always provide practical, actionable advice. Be concise but thorough.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        ...messages
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0].message.content || "I apologize, but I couldn't generate a response at this time.";
  } catch (error) {
    console.error('OpenAI API error:', error);
    throw new Error('Failed to generate AI response');
  }
}

export async function generateQuizQuestions(
  courseContent: string,
  questionCount: number = 5
): Promise<Array<{
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}>> {
  try {
    const prompt = `Based on the following course content, generate ${questionCount} multiple-choice quiz questions. Each question should have 4 options with one correct answer.

Course Content:
${courseContent}

Respond with JSON in this format:
{
  "questions": [
    {
      "question": "Question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "explanation": "Why this answer is correct"
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 1500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"questions":[]}');
    return result.questions || [];
  } catch (error) {
    console.error('Failed to generate quiz questions:', error);
    return [];
  }
}

export async function generateTrainingRecommendations(
  userPerformance: any,
  availableCourses: any[]
): Promise<string[]> {
  try {
    const prompt = `Based on the user's performance data and available courses, recommend the most suitable training modules.

User Performance:
${JSON.stringify(userPerformance, null, 2)}

Available Courses:
${JSON.stringify(availableCourses.map(c => ({ title: c.title, description: c.description, difficulty: c.difficulty })), null, 2)}

Respond with JSON in this format:
{
  "recommendations": ["Course Title 1", "Course Title 2", "Course Title 3"]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 500,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"recommendations":[]}');
    return result.recommendations || [];
  } catch (error) {
    console.error('Failed to generate training recommendations:', error);
    return [];
  }
}

export async function generatePhishingContent(
  templateType: string,
  targetAudience: string
): Promise<{ subject: string; content: string }> {
  try {
    const prompt = `Generate a realistic but safe phishing email template for cybersecurity training purposes.

Template Type: ${templateType}
Target Audience: ${targetAudience}

The email should be convincing but include subtle indicators that it's a training exercise. Include a disclaimer at the bottom.

Respond with JSON in this format:
{
  "subject": "Email subject line",
  "content": "HTML email content"
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_tokens: 800,
    });

    const result = JSON.parse(response.choices[0].message.content || '{"subject":"","content":""}');
    return {
      subject: result.subject || "Security Alert",
      content: result.content || "<p>This is a training email.</p>"
    };
  } catch (error) {
    console.error('Failed to generate phishing content:', error);
    return {
      subject: "Security Training Alert",
      content: "<p>This is a cybersecurity training exercise.</p>"
    };
  }
}
