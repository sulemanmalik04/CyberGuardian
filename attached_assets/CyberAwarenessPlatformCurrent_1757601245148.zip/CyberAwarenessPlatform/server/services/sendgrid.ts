import sgMail from '@sendgrid/mail';
import { storage } from '../storage';
import { AnalyticsEvent, PhishingCampaign, User } from '@shared/schema';

const apiKey = process.env.SENDGRID_API_KEY;
let isConfigured = false;

if (apiKey) {
  sgMail.setApiKey(apiKey);
  isConfigured = true;
  console.log('SendGrid service initialized successfully');
} else {
  console.warn('SendGrid API key not found. Email functionality will be disabled in development mode.');
}

interface PhishingEmailParams {
  to: string;
  subject: string;
  htmlContent: string;
  campaignId: string;
  userId: string;
  trackingDomain: string;
}

export async function sendPhishingEmail(params: PhishingEmailParams): Promise<boolean> {
  try {
    if (!isConfigured) {
      console.log(`[DEV MODE] Would send phishing email to ${params.to} with subject: ${params.subject}`);
      return true;
    }

    const trackingPixelUrl = `${params.trackingDomain}/api/tracking/open/${params.campaignId}/${params.userId}`;
    const clickTrackingUrl = `${params.trackingDomain}/api/tracking/click/${params.campaignId}/${params.userId}`;
    
    // Add tracking pixel and modify links
    const htmlWithTracking = params.htmlContent
      .replace(/<\/body>/i, `<img src="${trackingPixelUrl}" width="1" height="1" style="display:none;" /></body>`)
      .replace(/href="([^"]+)"/g, `href="${clickTrackingUrl}?url=$1"`);

    const msg = {
      to: params.to,
      from: process.env.SENDGRID_FROM_EMAIL || 'noreply@cybersecurity-training.com',
      subject: params.subject,
      html: htmlWithTracking,
    };

    await sgMail.send(msg);
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    return false;
  }
}

export async function sendBulkPhishingEmails(
  campaign: PhishingCampaign,
  users: Array<{ id: number; email: string }>,
  trackingDomain: string
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  for (const user of users) {
    const emailParams: PhishingEmailParams = {
      to: user.email,
      subject: campaign.template.subject,
      htmlContent: campaign.template.content,
      campaignId: campaign.id.toString(),
      userId: user.id.toString(),
      trackingDomain,
    };

    const sent = await sendPhishingEmail(emailParams);
    if (sent) {
      success++;
      
      // Log analytics event for successful send
      try {
        await storage.createAnalyticsEvent({
          clientId: campaign.clientId.toString(),
          userId: user.id.toString(),
          campaignId: campaign.id.toString(),
          eventType: 'email_sent',
          metadata: { email: user.email },
          ipAddress: null,
          userAgent: null,
        });
      } catch (error) {
        console.error('Failed to log email sent event:', error);
      }
    } else {
      failed++;
    }

    // Small delay to avoid rate limiting
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  return { success, failed };
}

export async function trackEmailOpen(campaignId: number, userId: number): Promise<boolean> {
  try {
    const campaign = await storage.getCampaign(campaignId);
    const user = await storage.getUser(userId);
    
    if (!campaign || !user) {
      return false;
    }

    // Update campaign tracking
    await storage.updateCampaign(campaign.id, {
      tracking: {
        sent: campaign.tracking?.sent || 0,
        opened: (campaign.tracking?.opened || 0) + 1,
        clicked: campaign.tracking?.clicked || 0,
        reported: campaign.tracking?.reported || 0,
      },
    });

    // Log analytics event
    await storage.createAnalyticsEvent({
      clientId: campaign.clientId.toString(),
      userId: user.id.toString(),
      campaignId: campaign.id.toString(),
      eventType: 'email_opened',
      metadata: { email: user.email },
      ipAddress: null,
      userAgent: null,
    });

    return true;
  } catch (error) {
    console.error('Failed to track email open:', error);
    return false;
  }
}

export async function trackEmailClick(campaignId: number, userId: number, url?: string): Promise<boolean> {
  try {
    const campaign = await storage.getCampaign(campaignId);
    const user = await storage.getUser(userId);
    
    if (!campaign || !user) {
      return false;
    }

    // Update campaign tracking
    await storage.updateCampaign(campaign.id, {
      tracking: {
        sent: campaign.tracking?.sent || 0,
        opened: campaign.tracking?.opened || 0,
        clicked: (campaign.tracking?.clicked || 0) + 1,
        reported: campaign.tracking?.reported || 0,
      },
    });

    // Log analytics event
    await storage.createAnalyticsEvent({
      clientId: campaign.clientId.toString(),
      userId: user.id.toString(),
      campaignId: campaign.id.toString(),
      eventType: 'link_clicked',
      metadata: url ? { clickedUrl: url } : null,
      ipAddress: null,
      userAgent: null,
    });

    return true;
  } catch (error) {
    console.error('Failed to track email click:', error);
    return false;
  }
}